// 页面加载状态管理
(() => {
    // 在DOM加载完成时初始化
    document.addEventListener('DOMContentLoaded', () => {
        // 标记页面正在加载
        document.body.classList.add('loading');
        
        // 创建加载进度条
        const loadingBar = document.createElement('div');
        loadingBar.className = 'page-loading-bar';
        document.body.appendChild(loadingBar);
        
        // 包装页面内容
        const mainContent = document.querySelector('main');
        if (mainContent) {
            mainContent.classList.add('content-container');
        }
        
        // 页面完全加载后（所有资源加载完毕）
        window.addEventListener('load', () => {
            // 等待进度条动画完成后显示内容 (0.8秒)
            setTimeout(() => {
                // 移除加载状态
                document.body.classList.remove('loading');
                
                // 显示内容
                if (mainContent) {
                    mainContent.classList.add('loaded');
                }
                
                // 移除加载条
                setTimeout(() => {
                    loadingBar.remove();
                }, 300);
            }, 800); // 与进度条动画时间一致 (0.8秒)
        });
    });
    
    // 页面切换时的处理（通过Pjax或类似技术）
    document.addEventListener('page:change', () => {
        // 如果网站使用PJAX，可以在这里处理页面切换时的加载
    });
})(); 