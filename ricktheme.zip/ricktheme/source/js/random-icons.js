/**
 * 随机图标生成器
 * 为每个卡片分配一个随机的Font Awesome图标
 */

(function() {
    // 定义不同类别的图标池
    const iconPools = {
        // 技术相关图标
        tech: [
            'fa-code', 'fa-terminal', 'fa-laptop-code', 'fa-database',
            'fa-microchip', 'fa-sitemap', 'fa-server', 'fa-mobile-alt',
            'fa-desktop', 'fa-laptop', 'fa-robot', 'fa-cloud',
            'fa-bug', 'fa-shield-alt', 'fa-wifi', 'fa-network-wired',
            'fa-code-branch', 'fa-git-alt', 'fa-github', 'fa-react'
        ],
        // 创意/设计相关图标
        creative: [
            'fa-palette', 'fa-paint-brush', 'fa-pencil-alt', 'fa-image',
            'fa-camera', 'fa-film', 'fa-video', 'fa-music', 
            'fa-headphones', 'fa-lightbulb', 'fa-drafting-compass', 'fa-ruler-combined',
            'fa-shapes', 'fa-bezier-curve', 'fa-crop', 'fa-layer-group'
        ],
        // 知识/教育相关图标
        knowledge: [
            'fa-book', 'fa-graduation-cap', 'fa-school', 'fa-university',
            'fa-atlas', 'fa-bookmark', 'fa-brain', 'fa-chalkboard-teacher',
            'fa-microscope', 'fa-flask', 'fa-atom', 'fa-dna',
            'fa-glasses', 'fa-globe', 'fa-language', 'fa-award'
        ],
        // 生活/兴趣相关图标
        lifestyle: [
            'fa-coffee', 'fa-utensils', 'fa-bicycle', 'fa-running',
            'fa-hiking', 'fa-mountain', 'fa-plane', 'fa-car',
            'fa-gamepad', 'fa-puzzle-piece', 'fa-chess', 'fa-guitar',
            'fa-camera-retro', 'fa-leaf', 'fa-spa', 'fa-heart'
        ],
        // 工具/实用相关图标
        tools: [
            'fa-tools', 'fa-wrench', 'fa-hammer', 'fa-screwdriver',
            'fa-calculator', 'fa-clock', 'fa-calendar', 'fa-calendar-alt',
            'fa-chart-bar', 'fa-chart-line', 'fa-chart-pie', 'fa-tasks',
            'fa-clipboard', 'fa-clipboard-list', 'fa-list', 'fa-clipboard-check'
        ]
    };

    // 参考图片中的特定图标 - 确保这些特殊图标可被分配
    const specialIcons = [
        'fa-laptop-code',   // 电脑代码图标
        'fa-mobile-alt',    // 手机图标
        'fa-chart-line',    // 图表图标
        'fa-shopping-cart', // 购物车图标
        'fa-gamepad',       // 游戏手柄图标
        'fa-robot',         // 机器人图标
        'fa-image'          // 图片图标
    ];

    // 所有图标合并为一个数组
    let allIcons = [];
    for (const category in iconPools) {
        allIcons = allIcons.concat(iconPools[category]);
    }
    
    // 添加特殊图标到数组开头，增加它们被选中的几率
    allIcons = [...specialIcons, ...allIcons];

    // 从localStorage获取已保存的图标分配
    function getSavedIcons() {
        const saved = localStorage.getItem('blogCardIcons');
        return saved ? JSON.parse(saved) : {};
    }

    // 保存图标分配到localStorage
    function saveIcons(iconsMap) {
        localStorage.setItem('blogCardIcons', JSON.stringify(iconsMap));
    }

    // 洗牌算法，随机排序数组
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    // 为每个卡片分配图标
    function assignIcons() {
        // 获取所有博客卡片
        const cards = document.querySelectorAll('.blog-card');
        if (!cards.length) return;

        // 获取保存的图标映射
        const savedIcons = getSavedIcons();
        
        // 创建新的图标分配
        const randomizedIcons = shuffleArray([...allIcons]);
        
        // 用于存储此次新分配的图标
        const newIconAssignments = {};
        
        // 已使用的图标集合，确保本页面内不重复
        const usedIcons = new Set();

        // 为每个卡片分配图标
        cards.forEach((card, index) => {
            // 获取文章ID或标题作为唯一标识
            const titleElement = card.querySelector('h2 a');
            if (!titleElement) return;
            
            const title = titleElement.textContent.trim();
            const path = titleElement.getAttribute('href');
            const cardId = path || title;
            
            // 检查是否已有保存的图标
            let iconClass;
            if (savedIcons[cardId]) {
                iconClass = savedIcons[cardId];
            } else {
                // 为特色卡片优先分配特殊图标
                if (card.classList.contains('featured-card') && specialIcons.length > 0) {
                    iconClass = specialIcons[Math.floor(Math.random() * specialIcons.length)];
                } else {
                    // 分配一个新图标，确保不重复
                    let attempts = 0;
                    do {
                        iconClass = randomizedIcons[Math.floor(Math.random() * randomizedIcons.length)];
                        attempts++;
                    } while (usedIcons.has(iconClass) && attempts < 30); // 尝试最多30次
                }
                
                newIconAssignments[cardId] = iconClass;
            }
            
            // 记录已使用的图标
            usedIcons.add(iconClass);
            
            // 创建并添加图标元素
            const iconContainer = card.querySelector('.card-icon-container');
            if (iconContainer) {
                iconContainer.innerHTML = `<i class="fas ${iconClass}"></i>`;
            }
        });
        
        // 合并并保存新的图标分配
        saveIcons({...savedIcons, ...newIconAssignments});
    }

    // 当DOM加载完成后执行
    document.addEventListener('DOMContentLoaded', assignIcons);
})(); 