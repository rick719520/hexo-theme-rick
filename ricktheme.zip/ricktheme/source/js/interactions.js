document.addEventListener('DOMContentLoaded', () => {
    // 添加涟漪效果
    function createRipple(event) {
        const button = event.currentTarget;
        const ripple = document.createElement('span');
        const rect = button.getBoundingClientRect();
        
        const diameter = Math.max(rect.width, rect.height);
        const radius = diameter / 2;
        
        ripple.style.width = ripple.style.height = `${diameter}px`;
        ripple.style.left = `${event.clientX - rect.left - radius}px`;
        ripple.style.top = `${event.clientY - rect.top - radius}px`;
        
        ripple.className = 'ripple';
        button.appendChild(ripple);
        
        ripple.addEventListener('animationend', () => {
            ripple.remove();
        });
    }

    // 为所有按钮添加涟漪效果
    const buttons = document.querySelectorAll('button, .btn, .nav-item');
    buttons.forEach(button => {
        button.classList.add('ripple-container');
        button.addEventListener('click', createRipple);
    });

    // 导航栏滚动效果
    const nav = document.querySelector('nav');
    nav.classList.add('nav-scroll');
    
    let lastScrollTop = 0;
    window.addEventListener('scroll', () => {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // 添加滚动效果
        if (scrollTop > 50) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }
        
        lastScrollTop = scrollTop;
    });

    // 为卡片添加悬停效果
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.classList.add('card-hover');
    });

    // 为按钮添加悬停效果
    const hoverButtons = document.querySelectorAll('.btn');
    hoverButtons.forEach(button => {
        button.classList.add('hover-effect');
    });
}); 