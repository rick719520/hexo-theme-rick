document.addEventListener('DOMContentLoaded', function() {
    // 设置页面加载动画
    initFadeAnimations();
    
    // 设置滚动动画
    initScrollAnimations();
    
    // 代码块处理
    enhanceCodeBlocks();
    
    // 图片处理
    enhanceImages();
    
    // 如果存在图表，初始化图表
    if (typeof Chart !== 'undefined') {
        initCharts();
    }
    
    // 文字拆分动画
    initTextSplit();
    
    // 初始化移动菜单
    initMobileMenu();
    
    // 初始化刷字效果和随机背景动画
    initBrushEffect();
});

/**
 * 初始化淡入淡出动画
 */
function initFadeAnimations() {
    const fadeElements = document.querySelectorAll('.fade-in');
    setTimeout(() => {
        fadeElements.forEach(el => {
            el.classList.add('visible');
        });
    }, 100);
}

/**
 * 初始化滚动触发动画
 */
function initScrollAnimations() {
    // 使用 Intersection Observer 监听元素是否进入视口
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });
    
    // 观察所有带有 data-scroll 属性的元素
    document.querySelectorAll('[data-scroll]').forEach(el => {
        observer.observe(el);
    });
}

/**
 * 增强代码块功能
 */
function enhanceCodeBlocks() {
    // 查找所有代码块
    const codeBlocks = document.querySelectorAll('pre code');
    
    codeBlocks.forEach(block => {
        // 创建代码块工具栏
        const toolbar = document.createElement('div');
        toolbar.className = 'code-toolbar flex justify-end p-2 border-b';
        toolbar.style.borderColor = 'var(--card-border)';
        
        // 添加复制按钮
        const copyButton = document.createElement('button');
        copyButton.className = 'copy-button p-1 rounded hover:bg-highlight/20 transition-colors';
        copyButton.innerHTML = '<i class="fas fa-copy"></i>';
        copyButton.title = '复制代码';
        
        // 复制功能
        copyButton.addEventListener('click', () => {
            const code = block.textContent;
            navigator.clipboard.writeText(code).then(() => {
                // 复制成功反馈
                copyButton.innerHTML = '<i class="fas fa-check"></i>';
                setTimeout(() => {
                    copyButton.innerHTML = '<i class="fas fa-copy"></i>';
                }, 2000);
            });
        });
        
        // 将按钮添加到工具栏
        toolbar.appendChild(copyButton);
        
        // 将工具栏添加到代码块容器
        const pre = block.parentNode;
        pre.style.position = 'relative';
        pre.style.padding = '0';
        pre.insertBefore(toolbar, block);
        
        // 调整代码块样式
        block.style.padding = '1rem';
        block.style.display = 'block';
        block.style.overflow = 'auto';
    });
}

/**
 * 增强图片功能
 */
function enhanceImages() {
    // 为文章内所有图片添加点击放大功能
    const contentImages = document.querySelectorAll('.post-content img');
    
    if (contentImages.length === 0) return;
    
    // 创建图片查看器容器
    const imageViewer = document.createElement('div');
    imageViewer.className = 'image-viewer fixed inset-0 bg-black/90 flex items-center justify-center z-50 opacity-0 pointer-events-none transition-opacity duration-300';
    imageViewer.style.backdropFilter = 'blur(10px)';
    
    // 添加关闭按钮
    const closeButton = document.createElement('button');
    closeButton.className = 'absolute top-4 right-4 text-white text-xl w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors';
    closeButton.innerHTML = '<i class="fas fa-times"></i>';
    imageViewer.appendChild(closeButton);
    
    // 图片容器
    const imageContainer = document.createElement('div');
    imageContainer.className = 'max-w-[90%] max-h-[90%] relative';
    
    // 图片元素
    const viewerImage = document.createElement('img');
    viewerImage.className = 'max-w-full max-h-[90vh] object-contain';
    imageContainer.appendChild(viewerImage);
    
    imageViewer.appendChild(imageContainer);
    document.body.appendChild(imageViewer);
    
    // 为每张图片添加点击事件
    contentImages.forEach(img => {
        img.style.cursor = 'zoom-in';
        img.addEventListener('click', () => {
            viewerImage.src = img.src;
            imageViewer.style.opacity = '1';
            imageViewer.style.pointerEvents = 'auto';
            document.body.style.overflow = 'hidden'; // 禁止滚动
        });
    });
    
    // 点击关闭查看器
    closeButton.addEventListener('click', closeImageViewer);
    imageViewer.addEventListener('click', (e) => {
        if (e.target === imageViewer) {
            closeImageViewer();
        }
    });
    
    // ESC 键关闭
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && imageViewer.style.opacity === '1') {
            closeImageViewer();
        }
    });
    
    function closeImageViewer() {
        imageViewer.style.opacity = '0';
        imageViewer.style.pointerEvents = 'none';
        document.body.style.overflow = ''; // 恢复滚动
    }
}

/**
 * 初始化图表 (如果页面中有图表)
 */
function initCharts() {
    const chartCanvases = document.querySelectorAll('.chart-canvas');
    
    chartCanvases.forEach(canvas => {
        try {
            const ctx = canvas.getContext('2d');
            const chartData = JSON.parse(canvas.getAttribute('data-chart'));
            
            new Chart(ctx, {
                type: chartData.type || 'bar',
                data: chartData.data,
                options: chartData.options || {
                    responsive: true,
                    maintainAspectRatio: true
                }
            });
        } catch (error) {
            console.error('初始化图表时出错:', error);
        }
    });
}

/**
 * 移动设备优化
 * 检测移动设备并应用特定优化
 */
(function() {
    // 检测是否为移动设备
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth < 768;
    
    // 如果是移动设备，执行优化
    if (isMobile) {
        // 为body添加移动设备标识类
        document.body.classList.add('is-mobile-device');
        
        // 减少非必要的动画，提升性能
        const animatedElements = document.querySelectorAll('.dot-pattern, .card-decorative-circle, .card-decorative-line');
        animatedElements.forEach(el => {
            el.style.opacity = '0.3';
        });
        
        // 延迟加载较低优先级的元素
        const lowPriorityElements = document.querySelectorAll('.wave-separator, .skill-section');
        lowPriorityElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transition = 'opacity 0.5s ease';
            
            // 在页面加载完成后延迟显示
            setTimeout(() => {
                el.style.opacity = '1';
            }, 500);
        });
        
        // 优化滚动性能
        let scrollTimeout;
        window.addEventListener('scroll', function() {
            if (!document.body.classList.contains('is-scrolling')) {
                document.body.classList.add('is-scrolling');
            }
            
            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(function() {
                document.body.classList.remove('is-scrolling');
            }, 200);
        });
        
        // 处理图片懒加载
        const lazyLoadImages = () => {
            const images = document.querySelectorAll('img[data-src]');
            images.forEach(img => {
                if (isElementInViewport(img)) {
                    img.src = img.getAttribute('data-src');
                    img.removeAttribute('data-src');
                }
            });
        };
        
        // 检查元素是否在可视区域内
        const isElementInViewport = (el) => {
            const rect = el.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        };
        
        // 初始运行懒加载
        lazyLoadImages();
        
        // 滚动时检查懒加载
        window.addEventListener('scroll', lazyLoadImages);
        
        // 使用passive选项提高滚动性能
        window.addEventListener('scroll', function() {
            // 空函数，仅为了使用passive选项
        }, { passive: true });
        
        // 减少技能标签的动画
        const techTags = document.querySelectorAll('.tech-tag');
        techTags.forEach(tag => {
            tag.style.animationDuration = '0s';
        });
    }
})();

// 文字拆分动画
function initTextSplit() {
    const element = document.querySelector('.split-text');
    if (!element) return;

    const text = element.textContent;
    element.textContent = '';
    
    [...text].forEach((char, index) => {
        const span = document.createElement('span');
        span.textContent = char;
        span.className = 'char';
        span.style.setProperty('--char-index', index);
        element.appendChild(span);
    });

    // 鼠标悬停时重新触发动画
    element.addEventListener('mouseenter', () => {
        const chars = element.querySelectorAll('.char');
        chars.forEach((char, index) => {
            char.style.animation = 'none';
            char.offsetHeight; // 触发重排
            char.style.animation = 'split-appear 0.4s cubic-bezier(0.4, 0, 0.2, 1) both';
            char.style.animationDelay = `${index * 0.05}s`;
        });
    });
}

/**
 * 初始化移动导航菜单
 */
function initMobileMenu() {
    const menuToggle = document.getElementById('mobile-menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    const mainContent = document.querySelector('main');
    
    // 检查必要的DOM元素
    if (!menuToggle) {
        return;
    }
    
    if (!mobileMenu) {
        return;
    }
    
    // 获取导航菜单的高度
    let menuHeight = 0;
    
    menuToggle.addEventListener('click', function() {
        if (mobileMenu.classList.contains('hidden')) {
            // 打开菜单
            mobileMenu.classList.remove('hidden');
            
            // 计算菜单高度
            menuHeight = mobileMenu.offsetHeight;
            
            // 增加主内容区域的顶部内边距，为菜单腾出空间
            const currentPadding = parseInt(getComputedStyle(mainContent).paddingTop);
            mainContent.style.paddingTop = `${currentPadding + menuHeight}px`;
            
            // 改变图标
            menuToggle.querySelector('i').classList.remove('fa-bars');
            menuToggle.querySelector('i').classList.add('fa-times');
        } else {
            // 关闭菜单
            mobileMenu.classList.add('hidden');
            
            // 恢复主内容区域的内边距
            mainContent.style.paddingTop = '';
            
            // 恢复图标
            menuToggle.querySelector('i').classList.remove('fa-times');
            menuToggle.querySelector('i').classList.add('fa-bars');
        }
    });
    
    // 移动端子菜单切换
    const mobileDropdownToggles = document.querySelectorAll('.mobile-dropdown-toggle');
    mobileDropdownToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const submenu = this.nextElementSibling;
            const arrow = this.querySelector('.mobile-dropdown-arrow');
            
            if (submenu.classList.contains('hidden')) {
                // 打开子菜单
                submenu.classList.remove('hidden');
                arrow.style.transform = 'rotate(180deg)';
                
                // 更新主内容的内边距
                setTimeout(() => {
                    const newMenuHeight = mobileMenu.offsetHeight;
                    const currentPadding = parseInt(getComputedStyle(mainContent).paddingTop);
                    const additionalHeight = newMenuHeight - menuHeight;
                    mainContent.style.paddingTop = `${currentPadding + additionalHeight}px`;
                    menuHeight = newMenuHeight;
                }, 10);
            } else {
                // 关闭子菜单
                submenu.classList.add('hidden');
                arrow.style.transform = 'rotate(0deg)';
                
                // 更新主内容的内边距
                setTimeout(() => {
                    const newMenuHeight = mobileMenu.offsetHeight;
                    const currentPadding = parseInt(getComputedStyle(mainContent).paddingTop);
                    const reducedHeight = menuHeight - newMenuHeight;
                    mainContent.style.paddingTop = `${currentPadding - reducedHeight}px`;
                    menuHeight = newMenuHeight;
                }, 10);
            }
        });
    });
    
    // 点击导航链接后自动关闭菜单
    document.querySelectorAll('#mobile-menu a').forEach(link => {
        link.addEventListener('click', function() {
            // 关闭菜单
            mobileMenu.classList.add('hidden');
            
            // 恢复主内容区域的内边距
            mainContent.style.paddingTop = '';
            
            // 恢复图标
            menuToggle.querySelector('i').classList.remove('fa-times');
            menuToggle.querySelector('i').classList.add('fa-bars');
        });
    });
    
    // 窗口调整大小时隐藏移动菜单
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            mobileMenu.classList.add('hidden');
            document.body.classList.remove('menu-open');
            mainContent.classList.remove('menu-open');
            menuToggle.querySelector('i').classList.remove('fa-times');
            menuToggle.querySelector('i').classList.add('fa-bars');
        }
    });
}

// 初始化刷字效果和随机背景动画
function initBrushEffect() {
    // 获取画布元素
    const canvas = document.getElementById('brush-canvas');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const text = "RICK719"; // 要绘制的文本
    const width = canvas.width;
    const height = canvas.height;
    
    // 初始化画布
    ctx.clearRect(0, 0, width, height);
    
    // 设置文本样式
    ctx.font = "bold 36px 'Brush Script MT', cursive";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    
    // 获取文字路径
    const textPath = [];
    const sampleRate = 0.5; // 采样率
    
    // 测量文本宽度
    const textWidth = ctx.measureText(text).width;
    const startX = (width - textWidth) / 2 + 10; // 微调起始位置
    const startY = height / 2;
    
    // 创建临时画布来获取文本路径
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = width;
    tempCanvas.height = height;
    const tempCtx = tempCanvas.getContext('2d');
    
    tempCtx.font = ctx.font;
    tempCtx.fillText(text, width / 2, height / 2);
    
    // 扫描临时画布获取文本路径点
    const imageData = tempCtx.getImageData(0, 0, width, height);
    for (let y = 0; y < height; y += 1/sampleRate) {
        for (let x = 0; x < width; x += 1/sampleRate) {
            const i = (Math.floor(y) * width + Math.floor(x)) * 4;
            if (imageData.data[i + 3] > 0) { // 如果有不透明像素
                textPath.push({x, y});
            }
        }
    }
    
    // 打乱点的顺序，使绘制更随机自然
    textPath.sort(() => Math.random() - 0.5);
    
    // 动画变量
    let pathIndex = 0;
    let isDone = false;
    let isDrawing = true;
    const totalPoints = Math.min(textPath.length, 1000); // 限制点数量
    const drawSpeed = 15; // 每帧绘制的点数
    
    // 渐变色
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, '#e31937');
    gradient.addColorStop(0.5, '#ff7e5f');
    gradient.addColorStop(1, '#e31937');
    
    // 获取RGB色值，用于光晕效果
    const getRGBValues = (color) => {
        const div = document.createElement('div');
        div.style.display = 'none';
        div.style.color = color;
        document.body.appendChild(div);
        const computedColor = getComputedStyle(div).color;
        document.body.removeChild(div);
        
        const match = computedColor.match(/\d+/g);
        return match ? match.map(Number) : [227, 25, 55]; // 默认红色
    };
    
    const highlightRGB = getRGBValues('#e31937');
    
    // 绘制函数
    function draw() {
        if (!isDrawing) return;
        
        // 绘制笔画
        ctx.fillStyle = gradient;
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 1.5;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        
        // 每帧绘制多个点
        for (let i = 0; i < drawSpeed && pathIndex < totalPoints; i++) {
            const point = textPath[pathIndex];
            pathIndex++;
            
            ctx.beginPath();
            ctx.arc(point.x, point.y, 1, 0, Math.PI * 2);
            ctx.fill();
        }
        
        // 完成绘制后添加发光效果
        if (pathIndex >= totalPoints && !isDone) {
            isDone = true;
            isDrawing = false;
            
            // 绘制完整文本（带发光效果）
            setTimeout(() => {
                // 清除画布
                ctx.clearRect(0, 0, width, height);
                
                // 添加发光效果
                ctx.shadowColor = `rgba(${highlightRGB[0]}, ${highlightRGB[1]}, ${highlightRGB[2]}, 0.8)`;
                ctx.shadowBlur = 10;
                
                // 绘制最终文本
                ctx.fillStyle = gradient;
                ctx.fillText(text, width / 2, height / 2);
                
                // 恢复默认阴影
                ctx.shadowColor = 'transparent';
                ctx.shadowBlur = 0;
            }, 300);
        } else if (!isDone) {
            requestAnimationFrame(draw);
        }
    }
    
    // 添加背景特效
    initBackgroundEffect();
    
    // 开始绘制
    draw();
    
    // 点击画布重新绘制
    canvas.addEventListener('click', resetAnimation);
    
    function resetAnimation() {
        pathIndex = 0;
        isDone = false;
        isDrawing = true;
        ctx.clearRect(0, 0, width, height);
        draw();
    }
}

// 初始化随机背景特效
function initBackgroundEffect() {
    const container = document.getElementById('background-effect-container');
    if (!container) return;
    
    // 清除任何现有内容
    container.innerHTML = '';
    
    // 随机选择背景特效 (0-4)
    const effectType = Math.floor(Math.random() * 5);
    
    switch (effectType) {
        case 0:
            createGeometricParticles(container);
            break;
        case 1:
            createFluidWaves(container);
            break;
        case 2:
            createStarryNight(container);
            break;
        case 3:
            createConnectedDots(container);
            break;
        case 4:
            createFloatingBubbles(container);
            break;
        default:
            createStarryNight(container); // 默认效果
    }
}

// 几何粒子效果
function createGeometricParticles(container) {
    const canvas = document.createElement('canvas');
    canvas.width = container.offsetWidth;
    canvas.height = container.offsetHeight;
    container.appendChild(canvas);
    
    const ctx = canvas.getContext('2d');
    const particles = [];
    const shapes = ['circle', 'triangle', 'square'];
    const colors = ['#e31937', '#ff7e5f', '#feb47b'];
    
    // 创建粒子
    for (let i = 0; i < 20; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            size: Math.random() * 8 + 2,
            speedX: Math.random() * 0.5 - 0.25,
            speedY: Math.random() * 0.5 - 0.25,
            shape: shapes[Math.floor(Math.random() * shapes.length)],
            color: colors[Math.floor(Math.random() * colors.length)],
            alpha: Math.random() * 0.5 + 0.3,
            rotation: Math.random() * 360
        });
    }
    
    function drawGeometricParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        particles.forEach(p => {
            ctx.save();
            ctx.globalAlpha = p.alpha;
            ctx.fillStyle = p.color;
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rotation * Math.PI / 180);
            
            switch (p.shape) {
                case 'circle':
                    ctx.beginPath();
                    ctx.arc(0, 0, p.size, 0, Math.PI * 2);
                    ctx.fill();
                    break;
                case 'triangle':
                    ctx.beginPath();
                    ctx.moveTo(0, -p.size);
                    ctx.lineTo(p.size, p.size);
                    ctx.lineTo(-p.size, p.size);
                    ctx.closePath();
                    ctx.fill();
                    break;
                case 'square':
                    ctx.fillRect(-p.size, -p.size, p.size * 2, p.size * 2);
                    break;
            }
            
            ctx.restore();
            
            // 更新位置
            p.x += p.speedX;
            p.y += p.speedY;
            p.rotation += 0.2;
            
            // 边界检查
            if (p.x < 0) p.x = canvas.width;
            if (p.x > canvas.width) p.x = 0;
            if (p.y < 0) p.y = canvas.height;
            if (p.y > canvas.height) p.y = 0;
        });
        
        requestAnimationFrame(drawGeometricParticles);
    }
    
    drawGeometricParticles();
}

// 流动波浪效果
function createFluidWaves(container) {
    const canvas = document.createElement('canvas');
    canvas.width = container.offsetWidth;
    canvas.height = container.offsetHeight;
    container.appendChild(canvas);
    
    const ctx = canvas.getContext('2d');
    let time = 0;
    
    function drawWaves() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // 创建渐变
        const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
        gradient.addColorStop(0, 'rgba(227, 25, 55, 0.2)');
        gradient.addColorStop(0.5, 'rgba(255, 126, 95, 0.2)');
        gradient.addColorStop(1, 'rgba(254, 180, 123, 0.2)');
        
        // 绘制多层波浪
        for (let i = 0; i < 3; i++) {
            ctx.beginPath();
            
            const amplitude = 10 - i * 2; // 振幅
            const frequency = 0.02 + i * 0.01; // 频率
            const timeOffset = i * Math.PI * 0.5; // 时间偏移
            
            ctx.moveTo(0, canvas.height / 2);
            
            for (let x = 0; x < canvas.width; x++) {
                const y = Math.sin((x * frequency) + time + timeOffset) * amplitude + canvas.height / 2;
                ctx.lineTo(x, y);
            }
            
            ctx.lineTo(canvas.width, canvas.height);
            ctx.lineTo(0, canvas.height);
            ctx.closePath();
            
            ctx.fillStyle = gradient;
            ctx.fill();
        }
        
        time += 0.05;
        requestAnimationFrame(drawWaves);
    }
    
    drawWaves();
}

// 星空闪烁效果
function createStarryNight(container) {
    const canvas = document.createElement('canvas');
    canvas.width = container.offsetWidth;
    canvas.height = container.offsetHeight;
    container.appendChild(canvas);
    
    const ctx = canvas.getContext('2d');
    const stars = [];
    
    // 创建星星
    for (let i = 0; i < 60; i++) {
        stars.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            size: Math.random() * 2 + 0.5,
            brightness: Math.random(),
            speed: 0.05 + Math.random() * 0.05
        });
    }
    
    // 流星
    let meteor = {
        active: false,
        startX: 0,
        startY: 0,
        endX: 0,
        endY: 0,
        progress: 0,
        speed: 0.02,
        tail: 80
    };
    
    function drawStars() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // 绘制星星
        stars.forEach(star => {
            ctx.beginPath();
            const brightness = 0.2 + Math.abs(Math.sin(Date.now() * star.speed) * 0.8);
            ctx.fillStyle = `rgba(255, 255, 255, ${brightness * star.brightness})`;
            ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
            ctx.fill();
        });
        
        // 绘制流星
        if (meteor.active) {
            const currentX = meteor.startX + (meteor.endX - meteor.startX) * meteor.progress;
            const currentY = meteor.startY + (meteor.endY - meteor.startY) * meteor.progress;
            
            // 绘制流星轨迹
            ctx.beginPath();
            ctx.moveTo(currentX, currentY);
            
            // 计算尾巴的长度和方向
            const angle = Math.atan2(meteor.endY - meteor.startY, meteor.endX - meteor.startX);
            const tailX = currentX - Math.cos(angle) * meteor.tail * meteor.progress;
            const tailY = currentY - Math.sin(angle) * meteor.tail * meteor.progress;
            
            // 创建渐变
            const gradient = ctx.createLinearGradient(currentX, currentY, tailX, tailY);
            gradient.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
            gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
            
            ctx.lineTo(tailX, tailY);
            ctx.strokeStyle = gradient;
            ctx.lineWidth = 2;
            ctx.stroke();
            
            // 更新进度
            meteor.progress += meteor.speed;
            
            // 重置流星
            if (meteor.progress >= 1) {
                meteor.active = false;
                setTimeout(createMeteor, Math.random() * 10000 + 5000); // 5-15秒后创建新流星
            }
        }
        
        requestAnimationFrame(drawStars);
    }
    
    function createMeteor() {
        // 初始化流星参数
        meteor.active = true;
        meteor.progress = 0;
        meteor.startX = Math.random() * canvas.width * 0.2;
        meteor.startY = Math.random() * canvas.height * 0.2;
        meteor.endX = canvas.width * (0.7 + Math.random() * 0.3);
        meteor.endY = canvas.height * (0.7 + Math.random() * 0.3);
        meteor.speed = 0.01 + Math.random() * 0.02;
        meteor.tail = 60 + Math.random() * 40;
    }
    
    // 初始流星出现时间
    setTimeout(createMeteor, Math.random() * 5000);
    
    drawStars();
}

// 连接的点效果
function createConnectedDots(container) {
    const canvas = document.createElement('canvas');
    canvas.width = container.offsetWidth;
    canvas.height = container.offsetHeight;
    container.appendChild(canvas);
    
    const ctx = canvas.getContext('2d');
    const dots = [];
    const connectionDistance = 80; // 点之间连线的最大距离
    
    // 创建点
    for (let i = 0; i < 30; i++) {
        dots.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            radius: Math.random() * 2 + 1,
            speedX: Math.random() * 0.5 - 0.25,
            speedY: Math.random() * 0.5 - 0.25,
            color: `rgba(227, 25, 55, ${Math.random() * 0.4 + 0.3})`
        });
    }
    
    function drawDots() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // 绘制点和连线
        dots.forEach((dot, i) => {
            // 绘制点
            ctx.beginPath();
            ctx.fillStyle = dot.color;
            ctx.arc(dot.x, dot.y, dot.radius, 0, Math.PI * 2);
            ctx.fill();
            
            // 更新位置
            dot.x += dot.speedX;
            dot.y += dot.speedY;
            
            // 边界检查
            if (dot.x < 0 || dot.x > canvas.width) dot.speedX *= -1;
            if (dot.y < 0 || dot.y > canvas.height) dot.speedY *= -1;
            
            // 绘制连线
            dots.forEach((otherDot, j) => {
                if (i !== j) {
                    const dx = dot.x - otherDot.x;
                    const dy = dot.y - otherDot.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance < connectionDistance) {
                        ctx.beginPath();
                        ctx.strokeStyle = `rgba(227, 25, 55, ${0.2 * (1 - distance / connectionDistance)})`;
                        ctx.lineWidth = 0.5;
                        ctx.moveTo(dot.x, dot.y);
                        ctx.lineTo(otherDot.x, otherDot.y);
                        ctx.stroke();
                    }
                }
            });
        });
        
        requestAnimationFrame(drawDots);
    }
    
    drawDots();
}

// 漂浮气泡效果
function createFloatingBubbles(container) {
    const canvas = document.createElement('canvas');
    canvas.width = container.offsetWidth;
    canvas.height = container.offsetHeight;
    container.appendChild(canvas);
    
    const ctx = canvas.getContext('2d');
    const bubbles = [];
    
    // 创建气泡
    for (let i = 0; i < 20; i++) {
        createBubble();
    }
    
    function createBubble() {
        bubbles.push({
            x: Math.random() * canvas.width,
            y: canvas.height + Math.random() * 20,
            radius: Math.random() * 10 + 3,
            speed: Math.random() * 0.8 + 0.2,
            color: `rgba(227, 25, 55, ${Math.random() * 0.1 + 0.05})`,
            stroke: `rgba(227, 25, 55, ${Math.random() * 0.2 + 0.1})`,
            pulseSpeed: Math.random() * 0.01 + 0.005,
            pulseAmount: Math.random() * 0.3 + 0.1,
            pulseOffset: Math.random() * Math.PI * 2
        });
    }
    
    function drawBubbles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        bubbles.forEach((bubble, index) => {
            // 脉动效果
            const pulseFactor = 1 + Math.sin(Date.now() * bubble.pulseSpeed + bubble.pulseOffset) * bubble.pulseAmount;
            const currentRadius = bubble.radius * pulseFactor;
            
            // 绘制气泡
            ctx.beginPath();
            ctx.fillStyle = bubble.color;
            ctx.strokeStyle = bubble.stroke;
            ctx.lineWidth = 1;
            ctx.arc(bubble.x, bubble.y, currentRadius, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
            
            // 添加高光
            ctx.beginPath();
            ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
            ctx.arc(bubble.x - currentRadius * 0.3, bubble.y - currentRadius * 0.3, currentRadius * 0.3, 0, Math.PI * 2);
            ctx.fill();
            
            // 更新位置
            bubble.y -= bubble.speed;
            
            // 轻微左右摆动
            bubble.x += Math.sin(Date.now() * 0.001 + index) * 0.3;
            
            // 如果气泡超出屏幕顶部，将其重置到底部
            if (bubble.y < -bubble.radius * 2) {
                bubbles.splice(index, 1);
                createBubble();
            }
        });
        
        requestAnimationFrame(drawBubbles);
    }
    
    drawBubbles();
} 