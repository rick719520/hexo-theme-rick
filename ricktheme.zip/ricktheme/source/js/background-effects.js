// 背景特效初始化
document.addEventListener('DOMContentLoaded', function() {
    initBackgroundEffects();
});

function initBackgroundEffects() {
    // 初始化浮动圆点
    initFloatingDots();
    
    // 初始化粒子效果
    initParticles();
    
    // 性能优化：监听滚动事件
    let ticking = false;
    window.addEventListener('scroll', function() {
        if (!ticking) {
            window.requestAnimationFrame(function() {
                optimizeBackgroundEffects();
                ticking = false;
            });
            ticking = true;
        }
    });
}

function initFloatingDots() {
    const container = document.querySelector('.floating-dots');
    if (!container) return;

    const isMobile = window.innerWidth <= 768;
    const dotCount = isMobile ? 15 : 30;
    
    for (let i = 0; i < dotCount; i++) {
        const dot = document.createElement('div');
        dot.className = 'dot';
        
        // 随机大小 (移动端较小)
        const size = isMobile ? 
            Math.random() * 20 + 10 : 
            Math.random() * 30 + 15;
        
        dot.style.width = `${size}px`;
        dot.style.height = `${size}px`;
        
        // 随机位置
        dot.style.left = `${Math.random() * 100}%`;
        
        // 随机动画延迟
        dot.style.animationDelay = `${Math.random() * 8}s`;
        
        container.appendChild(dot);
    }
}

function initParticles() {
    const particlesContainer = document.getElementById('particles-js');
    if (!particlesContainer || !window.particlesJS) return;

    const isMobile = window.innerWidth <= 768;
    
    particlesJS('particles-js', {
        particles: {
            number: {
                value: isMobile ? 30 : 60,
                density: {
                    enable: true,
                    value_area: 800
                }
            },
            color: {
                value: getComputedStyle(document.documentElement)
                    .getPropertyValue('--highlight-color').trim()
            },
            shape: {
                type: "circle"
            },
            opacity: {
                value: 0.3,
                random: true,
                animation: {
                    enable: true,
                    speed: 1,
                    minimumValue: 0.1,
                    sync: false
                }
            },
            size: {
                value: 3,
                random: true,
                animation: {
                    enable: true,
                    speed: 2,
                    minimumValue: 0.1,
                    sync: false
                }
            },
            move: {
                enable: true,
                speed: 1,
                direction: "none",
                random: true,
                straight: false,
                outModes: "out",
                bounce: false,
            }
        },
        interactivity: {
            detectsOn: "canvas",
            events: {
                onHover: {
                    enable: true,
                    mode: "grab"
                },
                resize: true
            },
            modes: {
                grab: {
                    distance: 140,
                    lineLinked: {
                        opacity: 0.1
                    }
                }
            }
        },
        retina_detect: true
    });
}

function optimizeBackgroundEffects() {
    const scrollY = window.scrollY;
    const windowHeight = window.innerHeight;
    const documentHeight = document.documentElement.scrollHeight;
    
    // 根据滚动位置调整背景效果的透明度
    const backgroundEffects = document.querySelector('.background-effects');
    if (backgroundEffects) {
        const opacity = Math.max(0.3, 1 - (scrollY / windowHeight * 0.5));
        backgroundEffects.style.opacity = opacity;
    }
    
    // 优化粒子效果
    const particlesContainer = document.getElementById('particles-js');
    if (particlesContainer) {
        const isVisible = scrollY < windowHeight;
        particlesContainer.style.display = isVisible ? 'block' : 'none';
    }
}

// 为页脚添加波浪效果
const footer = document.querySelector('footer');
if (footer) {
    const waveContainer = document.createElement('div');
    waveContainer.className = 'footer-wave-container';
    
    const wave1 = document.createElement('div');
    wave1.className = 'footer-wave footer-wave-1';
    
    const wave2 = document.createElement('div');
    wave2.className = 'footer-wave footer-wave-2';
    
    waveContainer.appendChild(wave1);
    waveContainer.appendChild(wave2);
    footer.insertBefore(waveContainer, footer.firstChild);
}

// 根据主题更新颜色
function updateThemeColors() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const root = document.documentElement;
    
    if (isDark) {
        root.style.setProperty('--wave-color-1', 'rgba(50, 50, 50, 0.1)');
        root.style.setProperty('--wave-color-2', 'rgba(50, 50, 50, 0.05)');
    } else {
        root.style.setProperty('--wave-color-1', 'rgba(200, 200, 200, 0.1)');
        root.style.setProperty('--wave-color-2', 'rgba(200, 200, 200, 0.05)');
    }
}

// 监听主题变化
const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.attributeName === 'data-theme') {
            updateThemeColors();
        }
    });
});

observer.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['data-theme']
});

// 初始化颜色
updateThemeColors();

// 处理鼠标移动时的渐变背景效果
document.addEventListener('mousemove', (e) => {
    // 移除渐变背景效果的鼠标跟踪
    return;
}); 