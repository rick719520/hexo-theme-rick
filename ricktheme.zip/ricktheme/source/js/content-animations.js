document.addEventListener('DOMContentLoaded', () => {
    // 初始化 Intersection Observer 用于文章卡片动画
    const cardObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                cardObserver.unobserve(entry.target); // 动画只执行一次
            }
        });
    }, {
        threshold: 0.1, // 当元素10%可见时触发
        rootMargin: '50px' // 提前50px触发
    });

    // 为所有文章卡片添加观察
    document.querySelectorAll('.article-card').forEach(card => {
        cardObserver.observe(card);
    });

    // 图片懒加载
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                const src = img.getAttribute('data-src');
                if (src) {
                    img.src = src;
                    img.classList.add('lazy-image');
                    
                    img.onload = () => {
                        img.classList.add('loaded');
                        imageObserver.unobserve(img);
                    };
                }
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '50px'
    });

    // 为所有懒加载图片添加观察
    document.querySelectorAll('img[data-src]').forEach(img => {
        // 添加占位效果
        img.classList.add('image-placeholder');
        imageObserver.observe(img);
    });

    // 视差效果
    let ticking = false;
    const parallaxContainers = document.querySelectorAll('.parallax-container');

    function updateParallax(e) {
        if (!ticking) {
            window.requestAnimationFrame(() => {
                parallaxContainers.forEach(container => {
                    const rect = container.getBoundingClientRect();
                    const centerX = rect.left + rect.width / 2;
                    const centerY = rect.top + rect.height / 2;
                    
                    // 计算鼠标位置相对于容器中心的偏移
                    const deltaX = (e.clientX - centerX) / 30;
                    const deltaY = (e.clientY - centerY) / 30;

                    // 更新容器内所有视差元素
                    container.querySelectorAll('.parallax-element').forEach(element => {
                        const depth = element.classList.contains('parallax-depth-1') ? 1 :
                                    element.classList.contains('parallax-depth-2') ? 2 :
                                    element.classList.contains('parallax-depth-3') ? 3 : 1;
                        
                        element.style.transform = `translate(${-deltaX * depth}px, ${-deltaY * depth}px)`;
                    });
                });
                ticking = false;
            });
            ticking = true;
        }
    }

    // 监听鼠标移动事件
    document.addEventListener('mousemove', updateParallax);

    // 监听滚动事件以更新视差效果
    let scrollTicking = false;
    window.addEventListener('scroll', () => {
        if (!scrollTicking) {
            window.requestAnimationFrame(() => {
                const scrolled = window.pageYOffset;
                parallaxContainers.forEach(container => {
                    const speed = 0.5;
                    const yOffset = scrolled * speed;
                    container.style.transform = `translate3d(0, ${yOffset}px, 0)`;
                });
                scrollTicking = false;
            });
            scrollTicking = true;
        }
    });
}); 