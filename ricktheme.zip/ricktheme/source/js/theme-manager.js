class ThemeManager {
    constructor() {
        this.root = document.documentElement;
        this.beijingCoords = {
            latitude: 39.9,    // 北京纬度
            longitude: 116.3   // 北京经度
        };
        this.isAutoMode = localStorage.getItem('theme-auto-mode') !== 'false'; // 默认自动模式
        this.initializeTheme();
        this.initializeToggle();
    }

    initializeTheme() {
        // 等待 SunCalc 库加载完成
        if (typeof SunCalc === 'undefined') {
            setTimeout(() => this.initializeTheme(), 100);
            return;
        }

        if (this.isAutoMode) {
            this.updateThemeBasedOnSunTimes();
            // 每分钟检查一次
            this.autoUpdateInterval = setInterval(() => this.updateThemeBasedOnSunTimes(), 60000);
        } else {
            // 使用保存的主题或默认深色主题
            const savedTheme = localStorage.getItem('manual-theme') || 'dark';
            this.setTheme(savedTheme);
        }
    }

    initializeToggle() {
        // 创建控制按钮组
        const toggleContainer = document.createElement('div');
        toggleContainer.className = 'fixed bottom-8 right-8 flex bg-gray-600/70 rounded-full backdrop-blur-sm z-50 overflow-hidden shadow-lg transition-all duration-300 hover:shadow-xl control-toggle-group';
        toggleContainer.innerHTML = `
            <button id="theme-toggle" class="p-3 flex items-center justify-center text-white hover:bg-gray-500/50 transition-all duration-300" title="${this.isAutoMode ? '自动主题模式' : this.getCurrentTheme() === 'dark' ? '暗色模式' : '亮色模式'}">
                <i class="fas ${this.isAutoMode ? 'fa-clock' : this.getCurrentTheme() === 'dark' ? 'fa-moon' : 'fa-sun'}"></i>
            </button>
            <div class="w-px h-6 self-center bg-white/20"></div>
            <button id="back-to-top" class="p-3 flex items-center justify-center text-white hover:bg-gray-500/50 transition-all duration-300" title="回到顶部">
                <i class="fas fa-arrow-up"></i>
            </button>
        `;
        document.body.appendChild(toggleContainer);

        // 处理滚动时的显示/隐藏
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                toggleContainer.classList.remove('opacity-0');
                toggleContainer.classList.remove('pointer-events-none');
            } else {
                toggleContainer.classList.add('opacity-0');
                toggleContainer.classList.add('pointer-events-none');
            }
        });
        
        // 初始状态为隐藏
        if (window.scrollY <= 300) {
            toggleContainer.classList.add('opacity-0');
            toggleContainer.classList.add('pointer-events-none');
        }

        // 主题切换按钮: 点击时切换自动/手动模式
        const themeToggle = document.getElementById('theme-toggle');
        themeToggle.addEventListener('click', () => {
            // 切换自动/手动模式
            this.isAutoMode = !this.isAutoMode;
            localStorage.setItem('theme-auto-mode', this.isAutoMode);
            
            if (this.isAutoMode) {
                // 切换到自动模式
                themeToggle.title = '自动主题模式';
                themeToggle.innerHTML = '<i class="fas fa-clock"></i>';
                this.updateThemeBasedOnSunTimes();
                this.autoUpdateInterval = setInterval(() => this.updateThemeBasedOnSunTimes(), 60000);
            } else {
                // 切换到手动模式
                clearInterval(this.autoUpdateInterval);
                const newTheme = this.getCurrentTheme() === 'dark' ? 'light' : 'dark';
                this.setTheme(newTheme);
                localStorage.setItem('manual-theme', newTheme);
                themeToggle.title = newTheme === 'dark' ? '暗色模式' : '亮色模式';
                themeToggle.innerHTML = `<i class="fas ${newTheme === 'dark' ? 'fa-moon' : 'fa-sun'}"></i>`;
            }
        });

        // 回到顶部按钮
        const backToTopButton = document.getElementById('back-to-top');
        backToTopButton.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    updateThemeBasedOnSunTimes() {
        const times = SunCalc.getTimes(
            new Date(), 
            this.beijingCoords.latitude, 
            this.beijingCoords.longitude
        );
        
        const now = new Date();
        const isDaytime = now > times.sunrise && now < times.sunset;
        
        this.setTheme(isDaytime ? 'light' : 'dark');
    }

    getCurrentTheme() {
        return this.root.getAttribute('data-theme') || 'dark';
    }

    setTheme(theme) {
        this.root.setAttribute('data-theme', theme);
        
        // 更新切换按钮图标
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.innerHTML = `<i class="fas ${theme === 'dark' ? 'fa-moon' : 'fa-sun'}"></i>`;
        }
    }
}

// 初始化主题管理器
window.addEventListener('DOMContentLoaded', () => {
    new ThemeManager();
}); 