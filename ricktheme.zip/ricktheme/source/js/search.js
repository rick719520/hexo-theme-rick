// 搜索功能实现
(function() {
  // 搜索数据
  var searchData;
  var searchDataPromise = null;
  
  // 从弹出搜索框获取元素
  var searchInput = document.getElementById('search-input');
  var searchResults = document.getElementById('search-results');
  var searchContainer = document.getElementById('search-container');
  var searchCloseBtn = document.querySelector('.search-close-btn');
  var searchBtn = document.querySelector('.search-btn');
  
  // 从首页搜索框获取元素
  var homeSearchInput = document.getElementById('home-search-input');
  var homeSearchButton = document.getElementById('home-search-button');
  
  // 从搜索结果页面获取元素
  var searchPageInput = document.getElementById('search-page-input');
  var searchPageButton = document.getElementById('search-page-button');
  var searchPageResults = document.getElementById('search-page-results');
  var searchKeywordDisplay = document.getElementById('search-keyword-display');
  var noResultsContainer = document.getElementById('no-results-container');
  var loadingIndicator = document.querySelector('.loading-indicator');

  // 处理搜索数据加载错误
  function handleSearchError(error, message) {
    searchData = [];
    if (loadingIndicator) {
      loadingIndicator.classList.add('hidden');
    }
    // 显示错误消息
    const errorEvent = new CustomEvent('search-error', { 
      detail: { message: message, error: error }
    });
    document.dispatchEvent(errorEvent);
  }

  // 加载搜索数据
  function loadSearchData() {
    // 如果已经有Promise在进行中，直接返回
    if (searchDataPromise) {
      return searchDataPromise;
    }
    
    // 如果数据已加载，直接返回
    if (searchData) {
      return Promise.resolve(searchData);
    }

    if (loadingIndicator) {
      loadingIndicator.classList.remove('hidden');
    }

    searchDataPromise = fetch('/search.xml')
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text();
      })
      .then(xmlText => {
        if (!xmlText.trim()) {
          throw new Error('搜索数据为空');
        }

        const parser = new DOMParser();
        const xml = parser.parseFromString(xmlText, 'text/xml');
        
        // 检查XML解析错误
        const parseError = xml.getElementsByTagName('parsererror');
        if (parseError.length > 0) {
          throw new Error('XML解析失败: ' + parseError[0].textContent);
        }
        
        searchData = Array.from(xml.getElementsByTagName('entry')).map(entry => {
          try {
            return {
              title: entry.getElementsByTagName('title')[0]?.textContent || '',
              content: entry.getElementsByTagName('content')[0]?.textContent || '',
              url: entry.getElementsByTagName('url')[0]?.textContent || '',
              date: entry.getElementsByTagName('date')[0]?.textContent || '',
              categories: Array.from(entry.getElementsByTagName('category')).map(category => category.textContent),
              tags: Array.from(entry.getElementsByTagName('tag')).map(tag => tag.textContent)
            };
          } catch (error) {
            return null;
          }
        }).filter(Boolean); // 移除解析失败的条目

        if (searchData.length === 0) {
          throw new Error('没有找到有效的搜索数据');
        }

        return searchData;
      })
      .catch(error => {
        handleSearchError(error, '加载搜索数据失败');
        return [];
      })
      .finally(() => {
        if (loadingIndicator) {
          loadingIndicator.classList.add('hidden');
        }
        searchDataPromise = null;
        
        // 如果在搜索结果页面，检查URL参数并执行搜索
        if (window.location.pathname === '/search/') {
          const urlParams = new URLSearchParams(window.location.search);
          const keyword = urlParams.get('keyword');
          if (keyword && searchPageResults) {
            performSearch(keyword, searchPageResults);
          }
        }
      });

    return searchDataPromise;
  }

  // 计算文本相关性分数
  function calculateRelevanceScore(text, keyword) {
    if (!text || !keyword) return 0;
    text = text.toLowerCase();
    keyword = keyword.toLowerCase();
    
    let score = 0;
    // 完全匹配
    if (text === keyword) score += 100;
    // 开头匹配
    else if (text.startsWith(keyword)) score += 60;
    // 包含匹配
    else if (text.includes(keyword)) score += 30;
    // 计算出现次数
    const matches = text.split(keyword).length - 1;
    if (matches > 1) score += Math.min(matches * 5, 40);
    
    return score;
  }

  // 执行搜索
  function performSearch(keyword, resultsContainer) {
    // 验证输入
    if (!searchData || !keyword.trim()) {
      handleEmptyResults(resultsContainer, '请输入搜索关键词');
      return;
    }

    const keywords = keyword.toLowerCase().trim().split(/\s+/);
    const results = [];
    
    // 对每个搜索项计算相关性分数
    for (const item of searchData) {
      let totalScore = 0;
      
      for (const kw of keywords) {
        // 标题匹配（权重最高）
        totalScore += calculateRelevanceScore(item.title, kw) * 2;
        
        // 标签匹配（权重次之）
        for (const tag of item.tags) {
          totalScore += calculateRelevanceScore(tag, kw) * 1.5;
        }
        
        // 分类匹配
        for (const category of item.categories) {
          totalScore += calculateRelevanceScore(category, kw) * 1.2;
        }
        
        // 内容匹配（权重最低）
        totalScore += calculateRelevanceScore(item.content, kw) * 0.5;
      }
      
      if (totalScore > 0) {
        results.push({
          item: item,
          score: totalScore
        });
      }
    }
    
    // 根据分数排序
    results.sort((a, b) => b.score - a.score);
    
    // 处理搜索结果
    if (results.length === 0) {
      handleEmptyResults(resultsContainer, '未找到相关文章');
    } else {
      displayResults(results.map(r => r.item), keyword, resultsContainer);
    }
  }

  // 处理空结果的情况
  function handleEmptyResults(resultsContainer, message) {
    resultsContainer.innerHTML = `<div class="search-result-empty">${message}</div>`;
    // 在搜索结果页面时，显示无结果容器
    if (window.location.pathname === '/search/' && noResultsContainer) {
      noResultsContainer.classList.remove('hidden');
    }
  }

  // 生成搜索页面的结果HTML
  function generateSearchPageResultHTML(item, title, content) {
    return `<div class="search-result-item my-6 p-6 rounded-lg transition-shadow hover:shadow-md" style="background-color: var(--card-bg);">
      <a href="${item.url}" class="search-result-title text-xl font-semibold mb-3 block hover:text-highlight transition-colors" style="color: #333;">${title}</a>
      <div class="search-result-content mb-4" style="color: var(--text-secondary);">${content}</div>
      <div class="search-result-meta flex flex-wrap gap-4 text-sm" style="color: var(--text-tertiary);">
        <span class="search-result-date flex items-center">
          <i class="far fa-calendar-alt mr-1"></i> ${item.date}
        </span>
        ${item.categories && item.categories.length ? 
          `<span class="search-result-categories flex items-center">
            <i class="fas fa-folder mr-1"></i> ${item.categories.join(', ')}
          </span>` : ''}
        ${item.tags && item.tags.length ? 
          `<span class="search-result-tags flex items-center flex-wrap">
            <i class="fas fa-tags mr-1"></i> ${item.tags.join(', ')}
          </span>` : ''}
      </div>
    </div>`;
  }

  // 生成弹出框的结果HTML
  function generatePopupResultHTML(item, title, content) {
    return `<div class="search-result-item">
      <a href="${item.url}" class="search-result-title">${title}</a>
      <div class="search-result-content">${content}</div>
      <div class="search-result-meta">
        <span class="search-result-date"><i class="far fa-calendar-alt"></i> ${item.date}</span>
        ${item.categories && item.categories.length ? 
          `<span class="search-result-categories"><i class="fas fa-folder"></i> ${item.categories.join(', ')}</span>` : ''}
        ${item.tags && item.tags.length ? 
          `<span class="search-result-tags"><i class="fas fa-tags"></i> ${item.tags.join(', ')}</span>` : ''}
      </div>
    </div>`;
  }

  // 显示搜索结果
  function displayResults(results, keyword, resultsContainer) {
    // 在搜索结果页面时，隐藏无结果容器
    if (window.location.pathname === '/search/' && noResultsContainer) {
      noResultsContainer.classList.add('hidden');
    }
    
    // 高亮关键词
    function highlightKeyword(text) {
      var reg = new RegExp(keyword, 'gi');
      return text.replace(reg, match => `<span class="highlight">${match}</span>`);
    }
    
    // 创建文档片段来提高性能
    const fragment = document.createDocumentFragment();
    
    results.forEach(item => {
      const title = highlightKeyword(item.title);
      const content = highlightKeyword(item.content.substring(0, 150) + '...');
      
      // 创建临时容器
      const tempContainer = document.createElement('div');
      tempContainer.innerHTML = window.location.pathname === '/search/' ?
        generateSearchPageResultHTML(item, title, content) :
        generatePopupResultHTML(item, title, content);
      
      // 将内容添加到文档片段
      while (tempContainer.firstChild) {
        fragment.appendChild(tempContainer.firstChild);
      }
    });
    
    // 清空容器并一次性添加所有结果
    resultsContainer.innerHTML = '';
    resultsContainer.appendChild(fragment);
  }

  // 跳转到搜索结果页面
  function redirectToSearchPage(keyword) {
    if (keyword && keyword.trim() !== '') {
      window.location.href = '/search/?keyword=' + encodeURIComponent(keyword.trim());
    }
  }

  // 显示搜索框
  function showSearchContainer() {
    searchContainer.style.display = 'flex';
    requestAnimationFrame(() => {
      searchContainer.classList.add('active');
      setTimeout(() => searchInput.focus(), 100);
    });
  }

  // 隐藏搜索框
  function hideSearchContainer() {
    searchContainer.classList.remove('active');
    setTimeout(() => {
      searchContainer.style.display = 'none';
      searchInput.value = '';
      searchResults.innerHTML = '';
    }, 300);
  }

  // 处理搜索框的关闭事件
  function handleSearchClose(e) {
    // 如果是ESC键，检查是否需要处理
    if (e.type === 'keydown' && (e.key !== 'Escape' || !searchContainer?.classList.contains('active'))) {
      return;
    }
    
    // 如果是点击事件，检查是否点击在搜索框外
    if (e.type === 'click' && searchContainer.contains(e.target) && e.target !== searchContainer) {
      return;
    }
    
    hideSearchContainer();
  }

  // 初始化搜索
  function initSearch() {
    // 加载搜索数据
    loadSearchData();
    
    // 弹出式搜索框事件监听
    if (searchInput) {
      searchInput.addEventListener('input', () => performSearch(searchInput.value, searchResults));
      
      // 添加回车键搜索并跳转功能
      searchInput.addEventListener('keyup', e => {
        if (e.key === 'Enter') {
          redirectToSearchPage(searchInput.value);
        }
      });
    }
    
    if (searchBtn) {
      searchBtn.addEventListener('click', e => {
        e.preventDefault();
        showSearchContainer();
      });
    }
    
    if (searchCloseBtn) {
      searchCloseBtn.addEventListener('click', hideSearchContainer);
    }
    
    // 点击搜索框外部关闭
    if (searchContainer) {
      searchContainer.addEventListener('click', handleSearchClose);
    }
    
    // ESC键关闭搜索
    document.addEventListener('keydown', handleSearchClose);
    
    // 首页搜索框事件监听
    if (homeSearchInput) {
      homeSearchInput.addEventListener('keyup', e => {
        if (e.key === 'Enter') {
          redirectToSearchPage(homeSearchInput.value);
        }
      });
    }
    
    if (homeSearchButton) {
      homeSearchButton.addEventListener('click', () => 
        redirectToSearchPage(homeSearchInput.value)
      );
    }
    
    // 搜索结果页面事件监听
    function handleSearchPageAction(keyword) {
      keyword = keyword.trim();
      if (keyword) {
        const url = new URL(window.location);
        url.searchParams.set('keyword', keyword);
        window.history.pushState({}, '', url);
        
        if (searchKeywordDisplay) {
          searchKeywordDisplay.textContent = `搜索: "${keyword}"`;
        }
        
        performSearch(keyword, searchPageResults);
      }
    }

    if (searchPageInput) {
      searchPageInput.addEventListener('keyup', e => {
        if (e.key === 'Enter') {
          handleSearchPageAction(searchPageInput.value);
        }
      });
    }
    
    if (searchPageButton) {
      searchPageButton.addEventListener('click', () => 
        handleSearchPageAction(searchPageInput.value)
      );
    }
  }

  // 暴露给全局，以便搜索结果页面可以调用
  window.searchPageInit = function(keyword) {
    // 确保数据已加载
    if (searchData) {
      performSearch(keyword, searchPageResults);
    } else {
      // 显示加载指示器
      if (loadingIndicator) {
        loadingIndicator.classList.remove('hidden');
      }
      
      // 加载数据后会自动执行搜索
      loadSearchData();
    }
  };

  // 页面加载完成后初始化
  window.addEventListener('load', initSearch);
})();