document.addEventListener('DOMContentLoaded', () => {
    const logoChars = document.querySelectorAll('.logo-char');
    const effects = ['effect-1', 'effect-2', 'effect-3'];
    let activeChar = null;
    let timeout = null;

    function removeEffects() {
        if (activeChar) {
            effects.forEach(effect => activeChar.classList.remove(effect));
            activeChar = null;
        }
    }

    function startEffect() {
        // 清除之前的效果
        removeEffects();
        clearTimeout(timeout);

        // 随机选择一个字符
        const randomIndex = Math.floor(Math.random() * logoChars.length);
        activeChar = logoChars[randomIndex];

        // 随机选择一个效果
        const effect = effects[Math.floor(Math.random() * effects.length)];
        activeChar.classList.add(effect);

        // 设置效果持续时间
        const duration = Math.random() * 1000 + 500; // 500-1500ms
        timeout = setTimeout(() => {
            removeEffects();
            // 设置下一次效果的延迟
            const nextDelay = Math.random() * 2000 + 1000; // 1000-3000ms
            timeout = setTimeout(startEffect, nextDelay);
        }, duration);
    }

    // 鼠标悬停时触发额外效果
    const logo = document.querySelector('.site-logo');
    logo.addEventListener('mouseenter', () => {
        // 清除当前的随机效果
        removeEffects();
        clearTimeout(timeout);

        // 为每个字符添加交错的动画
        logoChars.forEach((char, index) => {
            setTimeout(() => {
                char.classList.add('effect-2');
            }, index * 100);
        });
    });

    logo.addEventListener('mouseleave', () => {
        // 移除所有字符的效果
        logoChars.forEach(char => {
            effects.forEach(effect => char.classList.remove(effect));
        });
        // 重新开始随机效果
        setTimeout(startEffect, 500);
    });

    // 开始动画
    startEffect();
}); 