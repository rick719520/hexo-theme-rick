document.addEventListener('DOMContentLoaded', function() {
    // 获取域名标识元素
    const domainIdentifier = document.querySelector('.domain-3d');
    if (!domainIdentifier) return;

    // 获取容器和所有字符元素
    const container = document.querySelector('.domain-3d-container');
    const chars = domainIdentifier.querySelectorAll('.char');
    
    // 初始化字符位置
    chars.forEach(char => {
        const depth = parseFloat(char.getAttribute('data-depth')) || 0.1;
        char.style.transform = `translateZ(${depth * 50}px)`;
        char.style.transition = 'transform 0.2s ease';
    });
    
    // 添加鼠标移动视差效果
    window.addEventListener('mousemove', function(e) {
        if (!container.getBoundingClientRect) return;
        
        // 计算鼠标在屏幕上的相对位置
        const mouseX = e.clientX / window.innerWidth - 0.5;
        const mouseY = e.clientY / window.innerHeight - 0.5;
        
        // 计算容器相对于视口的位置
        const rect = container.getBoundingClientRect();
        const containerCenterX = rect.left + rect.width / 2;
        const containerCenterY = rect.top + rect.height / 2;
        
        // 检查鼠标是否在容器附近
        const distance = Math.sqrt(
            Math.pow((e.clientX - containerCenterX) / (window.innerWidth / 2), 2) + 
            Math.pow((e.clientY - containerCenterY) / (window.innerHeight / 2), 2)
        );
        
        // 如果鼠标距离较远，减小效果
        const proximityFactor = Math.max(0, 1 - Math.min(distance * 1.5, 1));
        
        // 为父容器添加倾斜效果
        const tiltX = mouseY * 20 * proximityFactor;
        const tiltY = -mouseX * 20 * proximityFactor;
        
        domainIdentifier.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg)`;
        
        // 为每个字符添加视差效果
        chars.forEach(char => {
            const depth = parseFloat(char.getAttribute('data-depth')) || 0.1;
            const moveX = mouseX * 70 * depth * proximityFactor;
            const moveY = mouseY * 70 * depth * proximityFactor;
            const moveZ = depth * 50;
            const rotateX = tiltX * depth * 0.5;
            const rotateY = tiltY * depth * 0.5;
            const scale = 1 + depth * 0.5 * proximityFactor;
            
            // 为"520"字符添加特殊效果
            let extraEffect = '';
            if (char.textContent === '5' || char.textContent === '2' || char.textContent === '0') {
                const pulseIntensity = (Math.sin(Date.now() * 0.003) + 1) * 0.1;
                extraEffect = ` scale(${scale + pulseIntensity})`;
            } else {
                extraEffect = ` scale(${scale})`;
            }
            
            char.style.transform = `translate3d(${moveX}px, ${moveY}px, ${moveZ}px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)${extraEffect}`;
            
            // 根据深度和鼠标位置调整阴影
            if (char.textContent === '5' || char.textContent === '2' || char.textContent === '0') {
                const shadowSize = 10 + depth * 20 * proximityFactor;
                const shadowBlur = 15 + depth * 30 * proximityFactor;
                char.style.textShadow = `
                    ${-moveX * 0.2}px ${-moveY * 0.2}px ${shadowBlur}px rgba(227, 25, 55, ${0.3 + depth * 0.7 * proximityFactor}),
                    0 0 ${shadowSize}px rgba(227, 25, 55, ${0.5 + depth * 0.5 * proximityFactor})
                `;
            } else {
                const shadowSize = 5 + depth * 10 * proximityFactor;
                char.style.textShadow = `
                    ${-moveX * 0.1}px ${-moveY * 0.1}px ${shadowSize}px rgba(0, 0, 0, ${0.2 + depth * 0.3 * proximityFactor})
                `;
            }
        });
    });
    
    // 添加鼠标离开容器效果
    container.addEventListener('mouseleave', function() {
        // 平滑过渡回初始状态
        domainIdentifier.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
        
        // 重置所有字符
        chars.forEach(char => {
            const depth = parseFloat(char.getAttribute('data-depth')) || 0.1;
            char.style.transform = `translateZ(${depth * 50}px)`;
            
            if (char.textContent === '5' || char.textContent === '2' || char.textContent === '0') {
                char.style.textShadow = '0 0 15px rgba(227, 25, 55, 0.7)';
            } else {
                char.style.textShadow = '0 0 5px rgba(0, 0, 0, 0.3)';
            }
        });
    });
    
    // 添加页面滚动效果
    window.addEventListener('scroll', function() {
        const rect = container.getBoundingClientRect();
        const centerY = rect.top + rect.height / 2;
        const viewportCenter = window.innerHeight / 2;
        const scrollFactor = (viewportCenter - centerY) / (window.innerHeight / 2);
        
        if (Math.abs(scrollFactor) < 1.5) {
            const rotateX = scrollFactor * 10;
            const translateY = scrollFactor * 20;
            domainIdentifier.style.transform = `perspective(1000px) rotateX(${rotateX}deg) translateY(${translateY}px)`;
            
            chars.forEach(char => {
                const depth = parseFloat(char.getAttribute('data-depth')) || 0.1;
                const moveZ = depth * 50 * (1 - Math.abs(scrollFactor) * 0.5);
                const moveY = scrollFactor * 30 * depth;
                char.style.transform = `translate3d(0, ${moveY}px, ${moveZ}px)`;
            });
        }
    });
        
    // 页面加载时的入场动画
    function introAnimation() {
        domainIdentifier.style.opacity = '1';
        
        chars.forEach((char, index) => {
        setTimeout(() => {
                char.style.opacity = '1';
                char.style.transform = `translateZ(${parseFloat(char.getAttribute('data-depth')) * 50}px)`;
            }, 100 * index);
        });
    }
    
    // 设置初始不可见状态
    domainIdentifier.style.opacity = '0';
    chars.forEach(char => {
        char.style.opacity = '0';
        char.style.transform = 'translateY(50px) translateZ(0px)';
    });
    
    // 启动入场动画
    setTimeout(introAnimation, 500);
}); 