class RightMenu {
    constructor() {
        this.rightMenu = null;
        this.init();
    }

    init() {
        // 创建自定义右键菜单
        this.createMenu();
        
        // 添加事件监听
        this.addEventListeners();
    }

    createMenu() {
        // 创建菜单元素
        this.rightMenu = document.createElement('div');
        this.rightMenu.className = 'custom-right-menu hidden';
        
        // 菜单内容
        this.rightMenu.innerHTML = `
            <div class="menu-container">
                <!-- 导航按钮 -->
                <div class="menu-row menu-nav-buttons">
                    <button class="menu-btn" title="后退" onclick="window.history.back()">
                        <i class="fas fa-arrow-left"></i>
                    </button>
                    <button class="menu-btn" title="前进" onclick="window.history.forward()">
                        <i class="fas fa-arrow-right"></i>
                    </button>
                    <button class="menu-btn" title="刷新" onclick="window.location.reload()">
                        <i class="fas fa-rotate"></i>
                    </button>
                    <button class="menu-btn" title="返回顶部" onclick="window.scrollTo({top: 0, behavior: 'smooth'})">
                        <i class="fas fa-arrow-up"></i>
                    </button>
                </div>
                
                <div class="menu-divider"></div>
                
                <!-- 主要功能 -->
                <div class="menu-item" id="random-post">
                    <i class="fas fa-random"></i>
                    <span>随便逛逛</span>
                </div>
                
                <div class="menu-item" onclick="window.location.href = '/categories/'">
                    <i class="fas fa-cube"></i>
                    <span>博客分类</span>
                </div>
                
                <div class="menu-item" onclick="window.location.href = '/tags/'">
                    <i class="fas fa-tags"></i>
                    <span>文章标签</span>
                </div>
                
                <div class="menu-divider"></div>
                
                <!-- 辅助功能 -->
                <div class="menu-item" id="copy-url">
                    <i class="fas fa-copy"></i>
                    <span>复制地址</span>
                </div>
                
                <div class="menu-item" id="theme-toggle-menu">
                    <i class="fas fa-circle-half-stroke"></i>
                    <span>深色模式</span>
                </div>
            </div>
        `;
        
        // 添加到body
        document.body.appendChild(this.rightMenu);
    }

    addEventListeners() {
        // 监听右键事件
        document.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.showMenu(e.clientX, e.clientY);
        });
        
        // 点击其他地方隐藏菜单
        document.addEventListener('click', () => {
            this.hideMenu();
        });
        
        // 按下ESC隐藏菜单
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.hideMenu();
            }
        });
        
        // 滚动时隐藏菜单
        document.addEventListener('scroll', () => {
            this.hideMenu();
        });
        
        // 主题切换
        document.getElementById('theme-toggle-menu').addEventListener('click', (e) => {
            this.toggleTheme();
            e.stopPropagation();
        });
        
        // 随机文章
        document.getElementById('random-post').addEventListener('click', (e) => {
            this.randomPost();
            e.stopPropagation();
        });
        
        // 复制地址
        document.getElementById('copy-url').addEventListener('click', (e) => {
            this.copyPageUrl();
            e.stopPropagation();
        });
    }

    showMenu(x, y) {
        // 确保菜单不会超出视口
        const menuWidth = 200; // 预估的菜单宽度
        const menuHeight = 300; // 预估的菜单高度
        
        // 调整菜单位置，确保不会超出视口
        if (x + menuWidth > window.innerWidth) {
            x = window.innerWidth - menuWidth;
        }
        
        if (y + menuHeight > window.innerHeight) {
            y = window.innerHeight - menuHeight;
        }
        
        // 设置菜单位置
        this.rightMenu.style.left = `${x}px`;
        this.rightMenu.style.top = `${y}px`;
        
        // 显示菜单
        this.rightMenu.classList.remove('hidden');
        
        // 更新主题按钮状态
        this.updateThemeToggleButton();
    }

    hideMenu() {
        if (this.rightMenu) {
            this.rightMenu.classList.add('hidden');
        }
    }

    randomPost() {
        // 获取所有文章链接
        const articleLinks = document.querySelectorAll('a[href^="/"][href$="/"]');
        
        if (articleLinks.length > 0) {
            // 随机选择一篇文章
            const randomIndex = Math.floor(Math.random() * articleLinks.length);
            const randomLink = articleLinks[randomIndex].getAttribute('href');
            
            // 跳转到随机文章
            window.location.href = randomLink;
        } else {
            alert('找不到文章链接');
        }
    }

    copyPageUrl() {
        const url = window.location.href;
        navigator.clipboard.writeText(url).then(() => {
            // 复制成功提示
            this.showToast('链接已复制到剪贴板');
        }).catch(err => {
            console.error('复制失败:', err);
        });
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        // 更新主题
        document.documentElement.setAttribute('data-theme', newTheme);
        
        // 在本地存储中保存用户选择
        localStorage.setItem('manual-theme', newTheme);
        localStorage.setItem('theme-auto-mode', 'false');
        
        // 如果存在主题管理器相关元素，更新它们
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.title = newTheme === 'dark' ? '暗色模式' : '亮色模式';
            themeToggle.innerHTML = `<i class="fas ${newTheme === 'dark' ? 'fa-moon' : 'fa-sun'}"></i>`;
        }
        
        // 清除自动模式的定时器
        if (window.autoUpdateInterval) {
            clearInterval(window.autoUpdateInterval);
        }
    }

    updateThemeToggleButton() {
        const themeButton = document.getElementById('theme-toggle-menu');
        const currentTheme = document.documentElement.getAttribute('data-theme');
        
        if (themeButton) {
            themeButton.querySelector('span').textContent = currentTheme === 'dark' ? '亮色模式' : '深色模式';
        }
    }

    showToast(message) {
        // 创建toast消息
        const toast = document.createElement('div');
        toast.className = 'toast-message';
        toast.textContent = message;
        
        // 添加到body
        document.body.appendChild(toast);
        
        // 显示toast
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        // 2秒后隐藏
        setTimeout(() => {
            toast.classList.remove('show');
            
            // 动画结束后移除元素
            toast.addEventListener('transitionend', () => {
                document.body.removeChild(toast);
            });
        }, 2000);
    }
}

// 页面加载后初始化右键菜单
document.addEventListener('DOMContentLoaded', () => {
    window.rightMenu = new RightMenu();
}); 