document.addEventListener('DOMContentLoaded', function() {
    const waveSeparator = document.querySelector('.wave-separator');
    if (!waveSeparator) return;

    // 波浪随着鼠标移动的效果，增强响应度
    document.addEventListener('mousemove', function(e) {
        if (!waveSeparator.getBoundingClientRect().top < window.innerHeight) return;
        
        // 计算相对于波浪区域的鼠标位置
        const rect = waveSeparator.getBoundingClientRect();
        const mouseX = e.clientX;
        const mouseY = e.clientY;
        
        // 扩大检测范围，提前触发效果
        const isNearWave = mouseY > rect.top - 200 && 
                          mouseY < rect.bottom + 200;
        
        if (isNearWave) {
            // 增大X方向的偏移量，提高响应度
            const offsetXRatio = (mouseX / window.innerWidth) * 2 - 1;
            const offsetX = offsetXRatio * 20;
            
            // 增强Y方向的浮动效果
            const distanceFromWaveCenter = Math.abs(mouseY - (rect.top + rect.height / 2));
            const offsetYRatio = Math.max(0, 1 - (distanceFromWaveCenter / 150));
            const offsetY = offsetYRatio * 30;
            
            // 应用增强的变换
            const waves = waveSeparator.querySelectorAll('.wave');
            waves.forEach((wave, index) => {
                const multiplier = index === 0 ? 1.2 : index === 1 ? 1.5 : 0.9;
                wave.style.transform = `translateX(${-offsetX * multiplier}%) translateY(${-offsetY * multiplier}px) scaleY(${1 + offsetY * 0.02 * multiplier})`;
            });
        } else {
            // 当鼠标离开时，重置变换
            const waves = waveSeparator.querySelectorAll('.wave');
            waves.forEach(wave => {
                wave.style.transform = '';
            });
        }
    });

    // 更强的随机浮动效果
    setInterval(() => {
        if (Math.random() < 0.7) { // 70%概率触发
            const waves = waveSeparator.querySelectorAll('.wave');
            const randomWave = waves[Math.floor(Math.random() * waves.length)];
            
            // 更大的随机变形
            const randomScaleY = 1 + (Math.random() * 0.2); // 0-20%的变形
            const randomTranslateY = (Math.random() * 10) - 5; // -5px到5px的随机上下移动
            
            randomWave.style.transform = `translateY(${randomTranslateY}px) scaleY(${randomScaleY})`;
            
            // 变形时间延长到500ms，更明显
            setTimeout(() => {
                randomWave.style.transform = '';
            }, 500);
        }
    }, 1000); // 频率提高到每秒一次

    // 添加淡入效果
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // 立即添加可见类，但设置一个短延迟让浏览器有时间开始过渡动画
                setTimeout(() => {
                    waveSeparator.classList.add('visible');
                }, 50);
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.2
    });
    
    observer.observe(waveSeparator);
}); 