/**
 * 代码量计数器动画效果
 */
document.addEventListener('DOMContentLoaded', function() {
    // 基准日期（博客开始记录代码量的日期）和基准代码量数据
    const baseDate = new Date('2023-01-01');
    const baseStats = [
        { id: 'js-lines', base: 248635, dailyIncrease: 42 },  // JavaScript每天增加42行
        { id: 'react-lines', base: 176432, dailyIncrease: 35 }, // React每天增加35行
        { id: 'css-lines', base: 94125, dailyIncrease: 18 },   // CSS每天增加18行
        { id: 'python-lines', base: 63841, dailyIncrease: 25 }, // Python每天增加25行
        { id: 'java-lines', base: 47582, dailyIncrease: 12 },  // Java每天增加12行
        { id: 'php-lines', base: 85764, dailyIncrease: 15 }    // PHP每天增加15行
    ];
    
    // 计算从基准日期到今天的天数
    const today = new Date();
    const timeDiff = today.getTime() - baseDate.getTime();
    const daysPassed = Math.floor(timeDiff / (1000 * 3600 * 24));
    
    // 根据经过的天数计算当前的代码量
    const codeStats = baseStats.map(stat => {
        // 计算该语言当前的代码行数
        const currentLines = stat.base + (daysPassed * stat.dailyIncrease);
        return { id: stat.id, target: currentLines };
    });
    
    // 计算总代码量
    const totalLines = codeStats.reduce((sum, stat) => sum + stat.target, 0);
    codeStats.push({ id: 'total-lines', target: totalLines });
    
    // 初始化并开始计数器动画
    function initCodeCounters() {
        // 为代码统计项目添加ID
        document.querySelectorAll('.code-stat-item').forEach((item, index) => {
            if (index < 6) { // 前6个是各语言统计
                item.querySelector('.code-stat-value').id = codeStats[index].id;
            }
        });
        
        // 为总代码量添加ID
        document.querySelector('.code-highlight').id = codeStats[6].id;
        
        // 启动动画
        animateCodeStats();
    }
    
    // 数字动画函数
    function animateNumber(element, target, duration = 1500) {
        if (!element) return;
        
        let start = 0;
        const increment = target / 100;
        const stepTime = Math.abs(Math.floor(duration / 100));
        let obj = { value: start };
        
        // 使用requestAnimationFrame实现平滑动画
        function step(timestamp) {
            if (obj.value < target) {
                obj.value += increment;
                if (obj.value > target) obj.value = target;
                element.textContent = Math.floor(obj.value).toLocaleString();
                requestAnimationFrame(step);
            }
        }
        
        requestAnimationFrame(step);
    }
    
    // 格式化数字为带千位分隔符的字符串
    function formatNumber(num) {
        return Math.floor(num).toLocaleString();
    }
    
    // 触发所有代码统计数据的动画
    function animateCodeStats() {
        codeStats.forEach(stat => {
            const element = document.getElementById(stat.id);
            if (element) {
                animateNumber(element, stat.target);
            }
        });
    }
    
    // 监听卡片可见性变化，当滚动到可见区域时启动动画
    function handleIntersection(entries, observer) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // 添加时间戳和天数提示
                const container = document.querySelector('.code-stats-container');
                if (container) {
                    // 在总代码量下方添加更新时间提示
                    const totalCodeEl = container.querySelector('.total-code');
                    if (totalCodeEl) {
                        const updateInfoEl = document.createElement('div');
                        updateInfoEl.className = 'text-xs text-gray-400 mt-1 text-center code-stats-update-info';
                        updateInfoEl.style.fontSize = '0.65rem';
                        updateInfoEl.innerHTML = `<i class="far fa-clock mr-1"></i>每日更新 · ${formatNumber(daysPassed)}天累计`;
                        totalCodeEl.parentNode.insertBefore(updateInfoEl, totalCodeEl.nextSibling);
                    }
                }
                
                initCodeCounters();
                observer.disconnect(); // 只执行一次
            }
        });
    }
    
    // 创建交叉观察器
    const observer = new IntersectionObserver(handleIntersection, {
        root: null,
        threshold: 0.1
    });
    
    // 观察代码统计容器
    const codeStatsContainer = document.querySelector('.code-stats-container');
    if (codeStatsContainer) {
        observer.observe(codeStatsContainer);
    } else {
        // 如果无法立即找到元素，等待DOM完全加载后再尝试
        window.addEventListener('load', () => {
            const container = document.querySelector('.code-stats-container');
            if (container) observer.observe(container);
        });
    }
}); 