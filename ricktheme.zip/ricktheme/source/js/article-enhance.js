/**
 * 文章增强功能脚本
 * 增强文章页面的交互功能
 */

(function() {
  // 等待DOM加载完成
  document.addEventListener('DOMContentLoaded', function() {
    // 初始化所有增强功能，但完全禁用代码复制按钮
    // initCodeCopyButtons(); // 禁用复制按钮功能
    initImageZoom();
    initHeadingLinks();
    initFootnoteTooltips();
    initTableWrapper();
    enhanceAppleStyleCodeBlocks(); // 添加苹果风格代码块增强
    
    // 添加目录滚动监听
    const tocLinks = document.querySelectorAll('.toc-list a');
    
    tocLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // 代码块处理
    const codeBlocks = document.querySelectorAll('.post-content pre');
    
    codeBlocks.forEach(pre => {
        // 检查是否已经添加了复制按钮
        if (pre.querySelector('.code-copy-btn')) {
            return;
        }
        
        // 创建复制按钮
        const copyButton = document.createElement('button');
        copyButton.className = 'copy-button';
        copyButton.innerHTML = '复制';
        copyButton.title = '复制代码';
        copyButton.setAttribute('aria-label', '复制代码');
        
        // 添加复制功能
        copyButton.addEventListener('click', function(e) {
            e.stopPropagation(); // 阻止事件冒泡
            const code = pre.querySelector('code');
            if (code) {
                // 使用现代剪贴板API
                navigator.clipboard.writeText(code.innerText).then(() => {
                    // 复制成功提示
                    copyButton.innerHTML = '已复制!';
                    
                    // 2秒后恢复按钮状态
                    setTimeout(() => {
                        copyButton.innerHTML = '复制';
                    }, 2000);
                    
                    // 显示Toast消息
                    showToast('代码已复制到剪贴板');
                }).catch(err => {
                    console.error('复制失败:', err);
                    copyButton.innerHTML = '失败';
                    
                    setTimeout(() => {
                        copyButton.innerHTML = '复制';
                    }, 2000);
                    
                    showToast('复制失败，请手动复制');
                });
            }
        });
        
        // 添加按钮到代码块
        pre.appendChild(copyButton);
    });
    
    // 创建Toast消息显示函数
    function showToast(message) {
        // 检查是否已存在Toast元素
        let toast = document.querySelector('.toast-message');
        
        // 如果不存在则创建
        if (!toast) {
            toast = document.createElement('div');
            toast.className = 'toast-message';
            document.body.appendChild(toast);
        }
        
        // 设置消息并显示
        toast.textContent = message;
        toast.classList.add('show');
        
        // 2秒后隐藏
        setTimeout(() => {
            toast.classList.remove('show');
        }, 2000);
    }
    
    // 滚动监听
    window.addEventListener('scroll', function() {
        const scrollPosition = window.scrollY;
        
        // 高亮当前目录项
        tocLinks.forEach(link => {
            const targetId = link.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const sectionTop = targetElement.offsetTop - 120;
                const sectionBottom = sectionTop + targetElement.offsetHeight;
                
                if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
                    tocLinks.forEach(item => item.classList.remove('active'));
                    link.classList.add('active');
                }
            }
        });
    });
  });

  /**
   * 苹果风格代码块增强
   */
  function enhanceAppleStyleCodeBlocks() {
    const codeBlocks = document.querySelectorAll('.post-content pre:not(.enhanced)');
    
    codeBlocks.forEach(pre => {
      // 标记为已增强
      pre.classList.add('enhanced');
      
      const codeElement = pre.querySelector('code');
      if (!codeElement) return;
      
      // 获取代码语言
      let language = '';
      const classNames = codeElement.className.split(' ');
      for (const className of classNames) {
        if (className.startsWith('language-')) {
          language = className.replace('language-', '');
          pre.setAttribute('data-lang', language);
          break;
        }
      }
      
      // 检测是否要加入终端效果
      if (language === 'bash' || language === 'sh' || language === 'shell') {
        pre.classList.add('terminal');
      }
      
      // 检查是否需要行号
      if (pre.classList.contains('line-numbers') || pre.hasAttribute('data-line-numbers')) {
        addLineNumbers(pre, codeElement);
      }
      
      // 处理长代码行，检查是否需要自动换行
      checkForLongLines(pre, codeElement);
    });
    
    // 观察DOM变化，处理新添加的代码块
    const observer = new MutationObserver(mutations => {
      let newCodeBlocks = false;
      
      mutations.forEach(mutation => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach(node => {
            if (node.nodeName === 'PRE' || 
                (node.nodeType === 1 && node.querySelector('pre:not(.enhanced)'))) {
              newCodeBlocks = true;
            }
          });
        }
      });
      
      if (newCodeBlocks) {
        enhanceAppleStyleCodeBlocks();
      }
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
  
  /**
   * 添加代码行号
   */
  function addLineNumbers(pre, codeElement) {
    pre.classList.add('line-numbers');
    
    // 将代码分割成行
    const code = codeElement.textContent;
    const lines = code.split('\n');
    
    // 清空代码元素
    codeElement.innerHTML = '';
    
    // 重建代码内容，每行包装在span中
    lines.forEach((line, index) => {
      if (index === lines.length - 1 && line === '') return; // 跳过最后一个空行
      
      const span = document.createElement('span');
      span.className = 'line';
      span.textContent = line;
      
      codeElement.appendChild(span);
      codeElement.appendChild(document.createTextNode('\n'));
    });
  }
  
  /**
   * 检查是否有长代码行
   */
  function checkForLongLines(pre, codeElement) {
    const code = codeElement.textContent;
    const lines = code.split('\n');
    let hasLongLine = false;
    
    for (const line of lines) {
      if (line.length > 80) { // 单行超过80个字符
        hasLongLine = true;
        break;
      }
    }
    
    if (hasLongLine) {
      pre.setAttribute('data-long-code', 'true');
      
      // 在移动设备上自动启用换行
      if (window.innerWidth < 768) {
        pre.style.whiteSpace = 'pre-wrap';
        pre.style.wordBreak = 'break-word';
      }
    }
  }

  /**
   * 为代码块添加复制按钮 - 已禁用
   */
  function initCodeCopyButtons() {
    // 此功能已被禁用
    return;
    
    // 下面的代码不会执行
    // 获取所有代码块
    const codeBlocks = document.querySelectorAll('.post-content pre');
    
    codeBlocks.forEach(block => {
      // 创建复制按钮
      const copyButton = document.createElement('button');
      copyButton.className = 'code-copy-btn';
      copyButton.setAttribute('title', '复制代码');
      copyButton.innerHTML = '<i class="fas fa-copy"></i>';
      
      // 设置按钮样式
      copyButton.style.position = 'absolute';
      copyButton.style.top = '8px';
      copyButton.style.right = '8px';
      copyButton.style.padding = '4px 8px';
      copyButton.style.background = 'var(--card-bg)';
      copyButton.style.border = '1px solid var(--card-border)';
      copyButton.style.borderRadius = '4px';
      copyButton.style.fontSize = '12px';
      copyButton.style.color = 'var(--text-secondary)';
      copyButton.style.cursor = 'pointer';
      copyButton.style.transition = 'all 0.2s ease';
      copyButton.style.opacity = '0';
      
      // 确保代码块有相对定位，以便按钮定位
      if (window.getComputedStyle(block).position === 'static') {
        block.style.position = 'relative';
      }
      
      // 添加复制按钮到代码块
      block.appendChild(copyButton);
      
      // 添加鼠标事件
      block.addEventListener('mouseenter', () => {
        copyButton.style.opacity = '1';
      });
      
      block.addEventListener('mouseleave', () => {
        copyButton.style.opacity = '0';
        // 如果按钮内容为"已复制"，恢复为复制图标
        if (copyButton.innerHTML !== '<i class="fas fa-copy"></i>') {
          setTimeout(() => {
            copyButton.innerHTML = '<i class="fas fa-copy"></i>';
          }, 300);
        }
      });
      
      // 添加复制功能
      copyButton.addEventListener('click', () => {
        const code = block.querySelector('code');
        const textToCopy = code.textContent;
        
        // 使用 navigator.clipboard API 复制文本
        navigator.clipboard.writeText(textToCopy).then(() => {
          // 复制成功，更新按钮状态
          copyButton.innerHTML = '<i class="fas fa-check"></i>';
          copyButton.style.color = 'var(--highlight-color)';
          
          // 2秒后恢复按钮
          setTimeout(() => {
            copyButton.innerHTML = '<i class="fas fa-copy"></i>';
            copyButton.style.color = 'var(--text-secondary)';
          }, 2000);
        }).catch(err => {
          // 复制失败
          console.error('复制失败:', err);
          copyButton.innerHTML = '<i class="fas fa-times"></i>';
          copyButton.style.color = 'red';
        });
      });
    });
  }

  /**
   * 图片点击放大查看功能
   */
  function initImageZoom() {
    // 获取文章中的所有图片
    const images = document.querySelectorAll('.post-content img');
    
    // 创建模态框元素
    const modal = document.createElement('div');
    modal.className = 'image-zoom-modal';
    modal.style.display = 'none';
    modal.style.position = 'fixed';
    modal.style.zIndex = '10000';
    modal.style.left = '0';
    modal.style.top = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.backgroundColor = 'rgba(0, 0, 0, 0.9)';
    modal.style.overflow = 'auto';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.cursor = 'zoom-out';
    modal.style.opacity = '0';
    modal.style.transition = 'opacity 0.3s ease';
    modal.style.visibility = 'hidden';
    
    // 创建放大的图片元素
    const modalImg = document.createElement('img');
    modalImg.className = 'image-zoom-modal-content';
    modalImg.style.maxWidth = '90%';
    modalImg.style.maxHeight = '90%';
    modalImg.style.objectFit = 'contain';
    modalImg.style.transition = 'transform 0.3s ease';
    
    // 创建关闭按钮
    const closeBtn = document.createElement('span');
    closeBtn.className = 'image-zoom-close';
    closeBtn.innerHTML = '&times;';
    closeBtn.style.position = 'absolute';
    closeBtn.style.top = '15px';
    closeBtn.style.right = '20px';
    closeBtn.style.color = 'white';
    closeBtn.style.fontSize = '35px';
    closeBtn.style.fontWeight = 'bold';
    closeBtn.style.cursor = 'pointer';
    
    // 添加图片说明元素
    const caption = document.createElement('div');
    caption.className = 'image-zoom-caption';
    caption.style.color = 'white';
    caption.style.padding = '10px';
    caption.style.textAlign = 'center';
    caption.style.maxWidth = '80%';
    caption.style.position = 'absolute';
    caption.style.bottom = '20px';
    caption.style.backgroundColor = 'rgba(0, 0, 0, 0.6)';
    caption.style.borderRadius = '4px';
    
    // 将元素添加到模态框和页面
    modal.appendChild(modalImg);
    modal.appendChild(closeBtn);
    modal.appendChild(caption);
    document.body.appendChild(modal);
    
    // 为每个图片添加点击事件
    images.forEach(img => {
      // 添加鼠标悬停特效
      img.style.cursor = 'zoom-in';
      
      img.addEventListener('click', function() {
        // 显示模态框
        modal.style.visibility = 'visible';
        modalImg.src = this.src;
        modal.style.opacity = '1';
        
        // 处理图片说明
        let captionText = '';
        // 尝试获取图片的alt属性作为说明
        if (this.alt && this.alt.trim() !== '') {
          captionText = this.alt;
        }
        // 如果图片后面紧跟着<em>标签，也可以用作说明
        const nextSibling = this.nextElementSibling;
        if (nextSibling && nextSibling.tagName.toLowerCase() === 'em') {
          captionText = nextSibling.textContent;
        }
        
        // 设置说明文本
        if (captionText) {
          caption.textContent = captionText;
          caption.style.display = 'block';
        } else {
          caption.style.display = 'none';
        }
        
        // 禁止页面滚动
        document.body.style.overflow = 'hidden';
      });
    });
    
    // 关闭模态框的事件处理
    modal.addEventListener('click', function(e) {
      if (e.target !== modalImg) {
        closeImageModal();
      }
    });
    
    closeBtn.addEventListener('click', closeImageModal);
    
    // 添加键盘支持 - 使用ESC关闭
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && modal.style.visibility === 'visible') {
        closeImageModal();
      }
    });
    
    // 关闭模态框函数
    function closeImageModal() {
      modal.style.opacity = '0';
      // 延迟改变visibility，使过渡效果完成
      setTimeout(() => {
        modal.style.visibility = 'hidden';
        // 恢复页面滚动
        document.body.style.overflow = '';
      }, 300);
    }
  }

  /**
   * 为文章标题添加锚点链接
   */
  function initHeadingLinks() {
    const headings = document.querySelectorAll('.post-content h1, .post-content h2, .post-content h3, .post-content h4, .post-content h5, .post-content h6');
    
    headings.forEach(heading => {
      // 只为有ID的标题添加链接
      if (heading.id) {
        // 创建锚点链接
        const link = document.createElement('a');
        link.className = 'heading-anchor';
        link.href = `#${heading.id}`;
        link.innerHTML = '<i class="fas fa-link"></i>';
        
        // 设置链接样式
        link.style.marginLeft = '0.5rem';
        link.style.fontSize = '0.8em';
        link.style.color = 'var(--text-secondary)';
        link.style.textDecoration = 'none';
        link.style.visibility = 'hidden';
        link.style.opacity = '0';
        link.style.transition = 'all 0.2s ease';
        
        // 将链接添加到标题中
        heading.appendChild(link);
        
        // 添加鼠标悬停效果
        heading.addEventListener('mouseenter', () => {
          link.style.visibility = 'visible';
          link.style.opacity = '1';
        });
        
        heading.addEventListener('mouseleave', () => {
          link.style.visibility = 'hidden';
          link.style.opacity = '0';
        });
        
        // 点击链接后复制URL到剪贴板
        link.addEventListener('click', (e) => {
          e.preventDefault();
          const url = window.location.href.split('#')[0] + link.getAttribute('href');
          navigator.clipboard.writeText(url).then(() => {
            // 显示复制成功提示
            showToast('链接已复制到剪贴板');
          }).catch(err => {
            console.error('复制链接失败:', err);
          });
          
          // 更新URL但不滚动
          history.pushState(null, null, link.getAttribute('href'));
          
          // 滚动到标题位置，带有偏移量以避免被固定头部遮挡
          const headerOffset = 70; // 根据你的固定头部高度调整
          const elementPosition = heading.getBoundingClientRect().top + window.pageYOffset;
          const offsetPosition = elementPosition - headerOffset;
          
          window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
          });
        });
      }
    });
  }

  /**
   * 为脚注添加工具提示
   */
  function initFootnoteTooltips() {
    const footnoteRefs = document.querySelectorAll('.post-content .footnote-ref');
    
    footnoteRefs.forEach(ref => {
      // 获取脚注链接
      const href = ref.querySelector('a').getAttribute('href');
      const id = href.substring(1); // 移除 # 获取ID
      
      // 获取对应的脚注内容
      const footnote = document.getElementById(id);
      if (!footnote) return;
      
      // 获取脚注内容文本
      const content = footnote.querySelector('p').textContent;
      
      // 创建工具提示元素
      const tooltip = document.createElement('div');
      tooltip.className = 'footnote-tooltip';
      tooltip.textContent = content;
      
      // 设置工具提示样式
      tooltip.style.position = 'absolute';
      tooltip.style.backgroundColor = 'var(--card-bg)';
      tooltip.style.color = 'var(--text-primary)';
      tooltip.style.border = '1px solid var(--card-border)';
      tooltip.style.borderRadius = '4px';
      tooltip.style.padding = '8px 12px';
      tooltip.style.fontSize = '14px';
      tooltip.style.maxWidth = '300px';
      tooltip.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
      tooltip.style.zIndex = '100';
      tooltip.style.opacity = '0';
      tooltip.style.visibility = 'hidden';
      tooltip.style.transition = 'opacity 0.2s ease, visibility 0.2s ease';
      
      // 添加工具提示到链接
      ref.style.position = 'relative';
      ref.appendChild(tooltip);
      
      // 鼠标悬停显示工具提示
      ref.addEventListener('mouseenter', () => {
        // 计算位置，保证工具提示不会超出视口
        const refRect = ref.getBoundingClientRect();
        const tooltipRect = tooltip.getBoundingClientRect();
        
        // 默认显示在下方
        let top = '24px';
        let left = '50%';
        let transform = 'translateX(-50%)';
        
        // 检查是否接近屏幕右侧
        if (refRect.left + tooltipRect.width/2 > window.innerWidth) {
          left = 'auto';
          right = '0';
          transform = 'none';
        }
        
        // 检查是否接近屏幕左侧
        if (refRect.left - tooltipRect.width/2 < 0) {
          left = '0';
          transform = 'none';
        }
        
        // 设置位置
        tooltip.style.top = top;
        tooltip.style.left = left;
        tooltip.style.right = right === '0' ? '0' : 'auto';
        tooltip.style.transform = transform;
        
        // 显示工具提示
        tooltip.style.visibility = 'visible';
        tooltip.style.opacity = '1';
      });
      
      // 鼠标离开隐藏工具提示
      ref.addEventListener('mouseleave', () => {
        tooltip.style.visibility = 'hidden';
        tooltip.style.opacity = '0';
      });
      
      // 点击脚注链接滚动到脚注位置
      ref.querySelector('a').addEventListener('click', (e) => {
        e.preventDefault();
        
        // 滚动到脚注，考虑到固定头部的偏移
        const targetElement = document.getElementById(id);
        const headerOffset = 80; // 根据你的固定头部高度调整
        const elementPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
        const offsetPosition = elementPosition - headerOffset;
        
        // 平滑滚动
        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
        
        // 更新URL但不滚动
        history.pushState(null, null, `#${id}`);
      });
    });
  }

  /**
   * 为表格添加包装器以实现响应式
   */
  function initTableWrapper() {
    const tables = document.querySelectorAll('.post-content table');
    
    tables.forEach(table => {
      // 检查表格是否已经有包装器
      if (table.parentNode.classList.contains('table-wrapper')) return;
      
      // 创建包装器
      const wrapper = document.createElement('div');
      wrapper.className = 'table-wrapper';
      wrapper.style.overflowX = 'auto';
      wrapper.style.width = '100%';
      wrapper.style.marginBottom = '1.5rem';
      
      // 将表格包装起来
      table.parentNode.insertBefore(wrapper, table);
      wrapper.appendChild(table);
    });
  }
})(); 