// 引入 SunCalc 库已在layout.ejs中完成

class ThemeManager {
    constructor() {
        this.root = document.documentElement;
        this.beijingCoords = {
            latitude: 39.9,    // 北京纬度
            longitude: 116.3   // 北京经度
        };
        this.isAutoMode = localStorage.getItem('theme-auto-mode') !== 'false'; // 默认自动模式
        this.initializeTheme();
        this.initializeToggle();
    }

    initializeTheme() {
        // 等待 SunCalc 库加载完成
        if (typeof SunCalc === 'undefined') {
            setTimeout(() => this.initializeTheme(), 100);
            return;
        }

        if (this.isAutoMode) {
            this.updateThemeBasedOnSunTimes();
            // 每分钟检查一次
            this.autoUpdateInterval = setInterval(() => this.updateThemeBasedOnSunTimes(), 60000);
        } else {
            // 使用保存的主题或默认深色主题
            const savedTheme = localStorage.getItem('manual-theme') || 'dark';
            this.setTheme(savedTheme);
        }
    }

    initializeToggle() {
        // 创建主题切换按钮
        const toggleContainer = document.createElement('div');
        toggleContainer.className = 'fixed bottom-4 right-4 flex gap-2 bg-gray-800/50 p-2 rounded-full backdrop-blur-sm z-50';
        toggleContainer.innerHTML = `
            <button id="theme-toggle" class="w-8 h-8 rounded-full flex items-center justify-center text-white hover:bg-gray-700/50 transition-colors">
                <i class="fas ${this.getCurrentTheme() === 'dark' ? 'fa-moon' : 'fa-sun'}"></i>
            </button>
            <button id="auto-toggle" class="w-8 h-8 rounded-full flex items-center justify-center text-white hover:bg-gray-700/50 transition-colors ${this.isAutoMode ? 'bg-highlight/50' : ''}">
                <i class="fas fa-clock"></i>
            </button>
        `;
        document.body.appendChild(toggleContainer);

        // 手动切换主题按钮
        const themeToggle = document.getElementById('theme-toggle');
        themeToggle.addEventListener('click', () => {
            if (!this.isAutoMode) {
                const newTheme = this.getCurrentTheme() === 'dark' ? 'light' : 'dark';
                this.setTheme(newTheme);
                localStorage.setItem('manual-theme', newTheme);
                themeToggle.innerHTML = `<i class="fas ${newTheme === 'dark' ? 'fa-moon' : 'fa-sun'}"></i>`;
            }
        });

        // 自动/手动模式切换按钮
        const autoToggle = document.getElementById('auto-toggle');
        autoToggle.addEventListener('click', () => {
            this.isAutoMode = !this.isAutoMode;
            localStorage.setItem('theme-auto-mode', this.isAutoMode);
            autoToggle.classList.toggle('bg-highlight/50');
            
            if (this.isAutoMode) {
                this.updateThemeBasedOnSunTimes();
                this.autoUpdateInterval = setInterval(() => this.updateThemeBasedOnSunTimes(), 60000);
            } else {
                clearInterval(this.autoUpdateInterval);
            }
        });
    }

    updateThemeBasedOnSunTimes() {
        const times = SunCalc.getTimes(
            new Date(), 
            this.beijingCoords.latitude, 
            this.beijingCoords.longitude
        );
        
        const now = new Date();
        const isDaytime = now > times.sunrise && now < times.sunset;
        
        this.setTheme(isDaytime ? 'light' : 'dark');
    }

    getCurrentTheme() {
        return this.root.getAttribute('data-theme') || 'dark';
    }

    setTheme(theme) {
        this.root.setAttribute('data-theme', theme);
        
        // 更新切换按钮图标
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.innerHTML = `<i class="fas ${theme === 'dark' ? 'fa-moon' : 'fa-sun'}"></i>`;
        }
    }
}

// 初始化主题管理器
window.addEventListener('load', () => {
    new ThemeManager();
}); 