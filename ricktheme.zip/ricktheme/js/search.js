/**
 * 博客搜索功能
 */
document.addEventListener('DOMContentLoaded', function() {
  // 搜索相关DOM元素
  const searchToggle = document.getElementById('search-toggle');
  const mobileSearchToggle = document.getElementById('mobile-search-toggle');
  const searchOverlay = document.getElementById('search-overlay');
  const searchContainer = document.getElementById('search-container');
  const searchInput = document.getElementById('search-input');
  const clearSearch = document.getElementById('clear-search');
  const searchResults = document.getElementById('search-results');
  const searchLoading = document.getElementById('search-loading');
  const searchNoResults = document.getElementById('search-no-results');
  
  // 搜索数据
  let searchData = null;
  let searchTimeout = null;
  const searchDelay = 300; // 搜索延迟（毫秒）
  
  // 初始化搜索数据
  function initSearchData() {
    if (searchData !== null) return Promise.resolve(searchData);
    
    searchLoading.classList.remove('hidden');
    return fetch('/search.json')
      .then(response => response.json())
      .then(data => {
        searchData = data;
        return data;
      })
      .catch(error => {
        console.error('加载搜索数据失败:', error);
        return [];
      })
      .finally(() => {
        searchLoading.classList.add('hidden');
      });
  }
  
  // 打开搜索弹窗
  function openSearch() {
    searchOverlay.classList.remove('hidden');
    setTimeout(() => {
      searchOverlay.classList.remove('opacity-0');
      searchContainer.classList.remove('scale-95');
      searchInput.focus();
    }, 10);
    
    initSearchData();
    
    // 禁止背景滚动
    document.body.style.overflow = 'hidden';
  }
  
  // 关闭搜索弹窗
  function closeSearch() {
    searchOverlay.classList.add('opacity-0');
    searchContainer.classList.add('scale-95');
    setTimeout(() => {
      searchOverlay.classList.add('hidden');
      // 清空搜索框和结果
      searchInput.value = '';
      searchResults.innerHTML = '';
      searchNoResults.classList.add('hidden');
    }, 300);
    
    // 恢复背景滚动
    document.body.style.overflow = '';
  }
  
  // 执行搜索
  function performSearch(keyword) {
    if (!searchData) return;
    
    keyword = keyword.toLowerCase().trim();
    
    if (!keyword) {
      searchResults.innerHTML = '';
      searchNoResults.classList.add('hidden');
      return;
    }
    
    // 过滤搜索结果
    const results = searchData.filter(post => {
      const titleMatch = post.title && post.title.toLowerCase().includes(keyword);
      const contentMatch = post.content && post.content.toLowerCase().includes(keyword);
      const tagsMatch = post.tags && post.tags.some(tag => tag.toLowerCase().includes(keyword));
      const categoriesMatch = post.categories && post.categories.some(cat => cat.toLowerCase().includes(keyword));
      
      return titleMatch || contentMatch || tagsMatch || categoriesMatch;
    });
    
    // 渲染搜索结果
    renderResults(results, keyword);
  }
  
  // 渲染搜索结果
  function renderResults(results, keyword) {
    searchResults.innerHTML = '';
    
    if (results.length === 0) {
      searchNoResults.classList.remove('hidden');
      return;
    }
    
    searchNoResults.classList.add('hidden');
    
    // 为每个结果创建元素
    results.forEach(post => {
      const resultItem = document.createElement('div');
      resultItem.className = 'py-4 px-2 hover:bg-gray-50 dark:hover:bg-gray-700 transition duration-150';
      
      // 高亮关键词
      const titleHtml = highlightKeyword(post.title, keyword);
      
      // 提取包含关键词的摘要
      let excerptHtml = '';
      if (post.content) {
        excerptHtml = extractExcerpt(post.content, keyword);
      }
      
      // 格式化日期
      const date = post.date ? new Date(post.date) : null;
      const dateStr = date ? date.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      }) : '';
      
      // 标签
      let tagsHtml = '';
      if (post.tags && post.tags.length) {
        tagsHtml = `
          <div class="flex flex-wrap gap-1 mt-2">
            ${post.tags.map(tag => `
              <span class="px-2 py-0.5 text-xs rounded bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300">
                ${tag}
              </span>
            `).join('')}
          </div>
        `;
      }
      
      resultItem.innerHTML = `
        <a href="${post.url}" class="block">
          <h3 class="text-lg font-medium text-gray-800 dark:text-gray-200">${titleHtml}</h3>
          ${excerptHtml ? `<p class="mt-1 text-sm text-gray-600 dark:text-gray-400">${excerptHtml}</p>` : ''}
          <div class="mt-2 flex items-center text-xs text-gray-500 dark:text-gray-400">
            <i class="far fa-calendar-alt mr-1"></i>
            <span>${dateStr}</span>
          </div>
          ${tagsHtml}
        </a>
      `;
      
      searchResults.appendChild(resultItem);
    });
  }
  
  // 高亮关键词
  function highlightKeyword(text, keyword) {
    if (!text) return '';
    
    const regex = new RegExp(`(${keyword})`, 'gi');
    return text.replace(regex, '<mark class="bg-yellow-200 dark:bg-yellow-700 px-0.5 rounded">$1</mark>');
  }
  
  // 提取包含关键词的摘要
  function extractExcerpt(content, keyword) {
    if (!content) return '';
    
    const maxLength = 100;
    content = content.replace(/<[^>]+>/g, ''); // 去除HTML标签
    
    const index = content.toLowerCase().indexOf(keyword.toLowerCase());
    if (index === -1) {
      return content.substring(0, maxLength) + '...';
    }
    
    const start = Math.max(0, index - 30);
    const end = Math.min(content.length, index + keyword.length + 30);
    let excerpt = content.substring(start, end);
    
    if (start > 0) excerpt = '...' + excerpt;
    if (end < content.length) excerpt += '...';
    
    return highlightKeyword(excerpt, keyword);
  }
  
  // 事件监听
  if (searchToggle) {
    searchToggle.addEventListener('click', openSearch);
  }
  
  if (mobileSearchToggle) {
    mobileSearchToggle.addEventListener('click', openSearch);
  }
  
  // 点击遮罩层关闭
  searchOverlay.addEventListener('click', (e) => {
    if (e.target === searchOverlay) {
      closeSearch();
    }
  });
  
  // 清空搜索
  clearSearch.addEventListener('click', () => {
    searchInput.value = '';
    searchInput.focus();
    searchResults.innerHTML = '';
    searchNoResults.classList.add('hidden');
  });
  
  // 搜索输入
  searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    const keyword = e.target.value;
    
    searchTimeout = setTimeout(() => {
      performSearch(keyword);
    }, searchDelay);
  });
  
  // ESC键关闭搜索
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !searchOverlay.classList.contains('hidden')) {
      closeSearch();
    }
  });
}); 