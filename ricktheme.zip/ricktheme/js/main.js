// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 随机图标库
    const icons = [
        'fa-compass',
        'fa-map',
        'fa-globe',
        'fa-bookmark',
        'fa-link',
        'fa-star',
        'fa-heart',
        'fa-gem',
        'fa-crown',
        'fa-rocket'
    ];

    // 为项目卡片添加随机图标
    const iconWrappers = document.querySelectorAll('.icon-wrapper i');
    iconWrappers.forEach(icon => {
        if (!icon.classList.contains('fa-code')) { // 不替换"更多项目"的图标
            const randomIcon = icons[Math.floor(Math.random() * icons.length)];
            icon.classList.remove(...icon.classList);
            icon.classList.add('fas', randomIcon);
        }
    });

    // 添加页面加载动画
    document.body.classList.add('loaded');

    // 为所有项目卡片添加点击事件
    const projectCards = document.querySelectorAll('.project-card');
    projectCards.forEach(card => {
        card.addEventListener('click', function() {
            // 这里可以添加更多的交互逻辑
        });
    });

    // 为项目卡片添加hover效果
    projectCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
        });

        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // 平滑滚动
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // 添加图片加载动画
    const images = document.querySelectorAll('img[loading="lazy"]');
    images.forEach(img => {
        img.addEventListener('load', function() {
            this.classList.add('loaded');
        });
    });
});

// 添加视差滚动效果
document.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    document.querySelector('.page-header').style.transform = `translateY(${scrolled * 0.5}px)`;
});

// 卡片入场动画
const cards = document.querySelectorAll('.project-card');
cards.forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
    }, index * 100);
});

// 图标悬浮动画
document.querySelectorAll('.icon-wrapper').forEach(icon => {
    icon.addEventListener('mouseenter', () => {
        icon.style.transform = 'rotate(15deg) scale(1.1)';
    });
    icon.addEventListener('mouseleave', () => {
        icon.style.transform = 'rotate(0) scale(1)';
    });
});

// 移动端菜单
const mobileMenuButton = document.getElementById('mobile-menu-button');
const mobileMenu = document.getElementById('mobile-menu');

mobileMenuButton.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
});

// 滚动动画
const scrollElements = document.querySelectorAll('[data-scroll]');

const elementInView = (el, offset = 0) => {
    const elementTop = el.getBoundingClientRect().top;
    return (
        elementTop <= 
        (window.innerHeight || document.documentElement.clientHeight) * (1 - offset)
    );
};

const displayScrollElement = (element) => {
    element.classList.add('is-visible');
};

const hideScrollElement = (element) => {
    element.classList.remove('is-visible');
};

const handleScrollAnimation = () => {
    scrollElements.forEach((el) => {
        if (elementInView(el, 0.25)) {
            displayScrollElement(el);
        } else {
            hideScrollElement(el);
        }
    });
};

// 鼠标移动效果
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.project-card');
    
    // 添加鼠标移动效果
    cards.forEach(card => {
        card.addEventListener('mousemove', e => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            // 更新CSS变量
            card.style.setProperty('--mouse-x', `${x}px`);
            card.style.setProperty('--mouse-y', `${y}px`);
            
            // 3D 倾斜效果
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            const rotateX = (y - centerY) / 20;
            const rotateY = (centerX - x) / 20;
            
            card.style.transform = `
                perspective(1000px)
                rotateX(${rotateX}deg)
                rotateY(${rotateY}deg)
                translateZ(10px)
            `;
        });
        
        // 重置卡片位置
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateZ(0)';
        });
    });
    
    // 添加滚动动画
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('in-view');
            }
        });
    }, observerOptions);
    
    cards.forEach(card => {
        observer.observe(card);
    });
});

// 鼠标跟随效果
const mouseFollower = document.createElement('div');
mouseFollower.classList.add('mouse-follower');
document.body.appendChild(mouseFollower);

document.addEventListener('mousemove', e => {
    mouseFollower.style.left = e.clientX + 'px';
    mouseFollower.style.top = e.clientY + 'px';
});

// 项目卡片尺寸分配
document.addEventListener('DOMContentLoaded', () => {
    const projectCards = document.querySelectorAll('.project-card');
    
    // 为不同的卡片分配不同的尺寸类
    projectCards.forEach((card, index) => {
        if (index === 0) {
            // 第一个项目使用大尺寸
            card.classList.add('large');
        } else if (index === projectCards.length - 1) {
            // "更多项目"使用中等尺寸
            card.classList.add('medium');
        } else {
            // 其他项目随机使用中等或小尺寸
            card.classList.add(Math.random() > 0.5 ? 'medium' : 'small');
        }
    });
});

// 平滑滚动
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// 添加视差滚动效果
window.addEventListener('scroll', () => {
    const cards = document.querySelectorAll('.project-card');
    cards.forEach(card => {
        const speed = 0.05;
        const rect = card.getBoundingClientRect();
        const scrolled = window.pageYOffset;
        
        if (rect.top <= window.innerHeight && rect.bottom >= 0) {
            const translateY = (rect.top - window.innerHeight / 2) * speed;
            card.style.transform = `translateY(${translateY}px)`;
        }
    });
});

// 初始化技术统计图表
const initTechChart = () => {
    const ctx = document.getElementById('techChart')?.getContext('2d');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['HTML/CSS', 'JavaScript', 'React', 'Vue', 'Node.js', 'Other'],
            datasets: [{
                label: '技术使用统计',
                data: [90, 85, 75, 70, 65, 50],
                backgroundColor: [
                    'rgba(255, 111, 97, 0.8)',
                    'rgba(255, 111, 97, 0.7)',
                    'rgba(255, 111, 97, 0.6)',
                    'rgba(255, 111, 97, 0.5)',
                    'rgba(255, 111, 97, 0.4)',
                    'rgba(255, 111, 97, 0.3)'
                ],
                borderColor: Array(6).fill('rgba(255, 111, 97, 1)'),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
};

// 页面加载完成后初始化
window.addEventListener('load', () => {
    initTechChart();
});