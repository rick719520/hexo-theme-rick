# RICK Theme 安装指南

## 前置条件

在安装本主题之前，请确保您已经：

1. 安装了 [Node.js](https://nodejs.org/) (推荐v14.0.0以上版本)
2. 安装了 [Hexo](https://hexo.io/) (推荐v6.0.0以上版本)
3. 创建了一个Hexo网站

如果您还没有创建Hexo网站，请按照以下步骤操作：

```bash
# 安装Hexo命令行工具
npm install -g hexo-cli

# 创建一个新的Hexo网站
hexo init my-blog
cd my-blog
npm install
```

## 安装主题

### 方法一：通过npm安装（推荐）

```bash
cd your-hexo-site
npm install hexo-theme-rick --save
```

### 方法二：手动下载安装

1. 下载本主题
```bash
cd your-hexo-site
git clone https://github.com/yourusername/hexo-theme-rick.git themes/ricktheme
```

2. 如果您不想使用git，也可以直接下载zip包并解压到`themes/ricktheme`目录

## 启用主题

修改Hexo站点配置文件 `_config.yml`：

```yaml
theme: ricktheme
```

## 安装依赖插件

为了获得最佳体验，推荐安装以下插件：

```bash
# 搜索功能
npm install hexo-generator-searchdb --save

# 字数统计
npm install hexo-word-counter --save

# 本地搜索
npm install hexo-generator-search --save

# RSS订阅
npm install hexo-generator-feed --save
```

## 主题配置

配置文件位于 `themes/ricktheme/_config.yml`。您可以根据自己的需求修改各项配置。

### 基本配置

1. 修改导航菜单：
```yaml
menu:
  首页: /
  归档: /archives
  分类: /categories
  标签: /tags
  关于: /about
```

2. 添加自定义下拉菜单：
```yaml
menu:
  自定义菜单: 
    text: 自定义菜单
    items:
      子菜单1: /page1
      子菜单2: /page2
```

3. 设置社交媒体链接：
```yaml
social:
  github: https://github.com/yourusername
  twitter: https://twitter.com/yourusername
  weibo: https://weibo.com/yourusername
```

### 高级配置

#### 主题模式设置

```yaml
theme:
  auto_mode: true     # 是否自动切换主题模式（根据时间）
  default: dark       # 默认主题模式: dark或light
```

#### 自定义主题颜色

```yaml
colors:
  highlight: '#64748B'
  highlight_rgb: '100, 116, 139'
```

## 创建关键页面

### 分类页面

```bash
hexo new page categories
```

然后编辑`source/categories/index.md`，添加：

```markdown
---
title: 分类
date: 2023-01-01 00:00:00
type: "categories"
layout: categories
---
```

### 标签页面

```bash
hexo new page tags
```

然后编辑`source/tags/index.md`，添加：

```markdown
---
title: 标签
date: 2023-01-01 00:00:00
type: "tags"
layout: tags
---
```

### 关于页面

```bash
hexo new page about
```

然后编辑`source/about/index.md`，添加您的个人信息。

## 常见问题

### Q: 网站加载速度慢怎么办？
A: 可以尝试以下方法提升加载速度：
   - 将Google Fonts和FontAwesome替换为本地字体
   - 压缩图片大小
   - 启用Hexo的压缩功能 `npm install hexo-minifier --save`

### Q: 如何添加自定义CSS？
A: 创建`source/css/custom.css`文件，添加您的自定义样式。

### Q: 如何添加评论功能？
A: 本主题支持Disqus、Valine、Gitalk等多种评论系统，请参考主题配置文件中的评论部分。

## 更新主题

### 通过npm更新

```bash
cd your-hexo-site
npm update hexo-theme-rick
```

### 手动更新

```bash
cd themes/ricktheme
git pull
```

## 寻求帮助

如果您在使用过程中遇到任何问题，欢迎：
- 查阅[主题文档](https://github.com/yourusername/hexo-theme-rick)
- 提交[Issue](https://github.com/yourusername/hexo-theme-rick/issues)
- 加入我们的QQ群或Telegram群组获取支持 